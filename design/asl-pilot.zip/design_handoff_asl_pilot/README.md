# Handoff: ASL Pilot — Redesign

## Overview

ASL Pilot is a self-study American Sign Language tutor for college students at the ASL 1 level. The product centers on a **camera-aware practice loop**: the learner sees a Deaf instructor's reference video, signs alongside it, and an on-device hand-pose model scores the match.

This handoff packages a full redesign of the existing product (23 screens) into **four design directions**, all driven by CSS custom properties so they're interchangeable. The product owner has selected **Foundry · Aurora** as the primary direction — implement that first. The other directions are documented for context and can be removed from the final build.

The product is positioned as "a Superbuilders project, made in Austin, TX." Brand voice is **editorial / academic** — closer to a university press field guide than a SaaS dashboard. It explicitly *does not* claim to teach fluency; it is a vocabulary tutor.

## About the design files

The HTML files in this bundle are **design references** — interactive prototypes that demonstrate the intended look, behavior, and interaction patterns. They are not production code to ship.

The implementation task is to **recreate these designs in the target codebase's existing environment** (React, Vue, Svelte, SwiftUI, native, etc.) using established patterns, component libraries, and routing solutions from that codebase. If no codebase exists yet, choose an appropriate framework — given the heavy reliance on a browser camera/WASM hand-pose model, a React + Vite + TypeScript SPA is a reasonable default.

## Fidelity

**High-fidelity.** Colors, typography, spacing, hover/focus states, and layout are final. Exact hex values, font families, and pixel measurements are documented below. Build pixel-perfectly using the target codebase's existing primitives — match the visual intent, not the HTML/CSS class names verbatim.

The prototype uses a hash router (`#/dashboard`, `#/practice/greetings`, etc.) for demo purposes. In production, use the codebase's routing solution (React Router, Next.js routes, etc.) with real URLs.

## Selected direction: Foundry · Aurora

Foundry is the dark, Superbuilders-aligned direction. Aurora is one of four color palettes inside Foundry; the others (Cobalt, Glacier, Ember) are listed under Design Tokens as alternates the owner may want available.

**Visual signature:**
- Deep navy backgrounds (#0f1a2e), never pure black
- Cyan → violet gradients on every emphasized element (primary buttons, accented words, progress bars, badges, "streak: 04", "rep: 1", lesson-complete checkmark)
- Background-clip:text used heavily — the gradient runs *through* important typography rather than sitting behind it
- **Striped stencil wordmark** for "ASL PILOT" in the nav (matches the SUPERBUILDERS treatment on superbuilders.school)
- Monospace body copy (JetBrains Mono) throughout — references, captions, body paragraphs, footnotes
- Heavy display sans (Inter 800/900) for headlines and section titles
- Subtle corner glows on hero areas — two radial gradients (cyan + violet) bleeding from opposite corners
- No purely decorative imagery; placeholders are diagonal-stripe panels with a small mono caption indicating what should be filled in

## Screens / Views

The product has **23 screens** plus a designer-notes route. Group structure:

### Public (5)
| # | Route | Purpose |
|---|-------|---------|
| 01 | `/` | Landing — title + lede + CTA + footer credit |
| 02 | `/signin` | Sign in with email + password, with "forgot" / "demo as guest" affordances |
| 03 | `/signup` | Create account: display name, email, password, confirm |
| 04 | `/forgot` | Request password reset link |
| 05 | `/verify` | Six-digit code input, auto-advance on completion |

### Onboarding (4 steps)
| # | Route | Purpose |
|---|-------|---------|
| 06 | `/onboarding` | Welcome — explains scope, privacy, limits |
| 07 | `/onboarding/camera` | Request camera permission (with denied + re-enable flow) |
| 08 | `/onboarding/calibrate` | Frame check + mirror toggle |
| 09 | `/onboarding/first-sign` | Guided practice on HELLO with the three drills |

### App (5)
| # | Route | Purpose |
|---|-------|---------|
| 10 | `/dashboard` | Welcome, course progress, recent lessons, 75-day heatmap, streak |
| 11 | `/lessons` | Catalog: search, category chips, list of 12 lessons with sign chips |
| 12 | `/lesson/:slug` | Lesson intro: signs list + practice-settings panel (camera / reference toggles) |
| 13 | `/practice/:slug` | **The hero screen.** Camera + reference side-by-side, 3-stage progress, rep counter, hint, CTAs |
| 14 | `/complete/:slug` | Summary: stats, mastery snapshot per sign, continue / dashboard |

### Settings & info (6)
| # | Route | Purpose |
|---|-------|---------|
| 15 | `/settings/account` | Display name, email (locked), password, danger zone |
| 16 | `/settings/app` | Practice defaults, playback speed, auto-advance |
| 17 | `/settings/notifications` | Email categories + streak reminder hour |
| 18 | `/privacy` | Plain-language privacy doc (camera, telemetry, export, cookies) |
| 19 | `/help` | How-it-works + 5 FAQs + support email |
| 20 | `/about` | Demonstrator credits, model description, team, colophon |

### Error states (3)
| # | Route | Purpose |
|---|-------|---------|
| 21 | `/error/camera` | Camera blocked — re-enable or self-report mode |
| 22 | `/error/offline` | Network down — three tips + retry |
| 23 | `*` | 404 — back to dashboard or browse lessons |

### Hero screen detail — Practice (`/practice/:slug`)

The most important screen in the product. Build this first.

**Layout (desktop, ≥780px):**
```
┌──────────────────────────────────────────────────────────────┐
│ ← Lesson · Greetings   Sign 1 of 7  Back drill  Pause  Exit  │ <- 56px sticky header
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  NOW SIGNING                                            REP   │
│                                                               │
│  HELLO                                                   1/3  │ <- h1, clamp(3rem, 7vw, 5.5rem)
│                                                               │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐         │
│  │ 01 Handshape │ │ 02 Movement  │ │ 03 Whole sign │         │ <- 3-stage tabs, active highlighted
│  └──────────────┘ └──────────────┘ └──────────────┘         │
│                                                               │
│  YOUR CAMERA          live · on-device                        │
│  REFERENCE · HANDSHAPE   Maya R. · 0.5×                       │
│  ┌────────────────────────┐ ┌────────────────────────┐       │
│  │  [camera preview]      │ │  [reference video]     │       │
│  │  [±67% match overlay]  │ │  [↻ 0.5× 1× controls]  │       │
│  └────────────────────────┘ └────────────────────────┘       │
│                                                               │
│  [? Show a hint]              [Restart sign]                 │
│                                                               │
│  [Skip this sign →]                       [Continue →]        │
│  Tap continue when you're ready — or the camera will          │
│  auto-advance once it detects a match.                        │
└──────────────────────────────────────────────────────────────┘
```

**Layout (mobile, <780px):** Camera and reference stack vertically. Three-stage tabs stack to single column under 600px. CTA row wraps; primary button takes full width.

**Components:**
- **Header bar** — sticky, height 56px, 1px bottom border `var(--line-soft)`. Left: back chevron + "Lesson · {title}". Right: sign counter (mono), back-a-drill / back-a-sign links, divider line, Pause and Exit ghost buttons.
- **Title row** — Eyebrow ("NOW SIGNING") + h1 (the sign word). In Foundry the h1 has `text-transform: lowercase` but uppercase letterforms are typeset via `font-feature-settings: "smcp"` — defaults to uppercase. Right side: Eyebrow ("REP") + rep number with gradient text-fill, e.g. `1 / 3`.
- **3-stage progress** — flex row of three pill-shaped cards. Active card uses `accent-bg` background + accent border. Done cards show ✓ in success green. Pending cards are muted.
- **Camera cell** — 4:3 aspect ratio, rounded-12, 1px subtle border. Top-right floating pill overlay with live match score (`±67% match`) and a pulsing green dot. Caption above: eyebrow "YOUR CAMERA" + mono "live · on-device".
- **Reference cell** — same dimensions. Caption: "REFERENCE · {stage}" + mono "Maya R. · 0.5×". Bottom-left floating pill with playback controls: loop, 0.5×, 1×.
- **Hint row** — between cells and CTAs. Bordered top + bottom (1px line-soft). When `showHint` is false: a quiet small button "? Show a hint". When true: an accent-tinted card with the hint text. Always: ghost "Restart sign" on the right.
- **CTA row** — left: ghost "Skip this sign →". Right: primary button. Label changes by state: "Continue →" / "Next rep (X of 3) →" / "Next sign →" / "Finish lesson ✓".

**State transitions:**
- Each sign has 3 stages (handshape, movement, whole sign), each repeated 3 times → 9 advances per sign.
- Pressing **Continue**: stage 0 → 1 → 2 → rep+1, stage reset to 0. After rep 3 stage 2, advance to next sign. After last sign, navigate to `/complete/:slug`.
- **Back a drill** undoes one stage. **Back a sign** jumps to previous sign, last stage of last rep.
- **Skip this sign** advances signIdx + 1 (no rep change).
- **Restart sign** resets stage to 0, rep to 1, keeps signIdx.

### Sign data shape

```ts
type Lesson = {
  slug: string;       // "greetings", "numbers", ...
  num: number;        // 1..12
  title: string;      // "Greetings"
  count: number;      // 7
  mins: number;       // estimated practice minutes
  signs: string[];    // ["HELLO", "GOODBYE", ...] — uppercase glossed names
};
```

12 lessons total, ~75 signs total. Full seed data lives in `src/screens-main.jsx` as `LESSONS`. Greetings (7), Numbers 1–20 (7), Family (6), Feelings (6), Food & drink (6), Time (6), Places (6), Common verbs (7), Question words (6), Colors (6), Animals (6), Everyday phrases (6).

## Interactions & Behavior

### Routing
Hash-based in the prototype. Real product should use the codebase's router. Required paths listed in the Screens table above. The catch-all should land on the 404 screen.

### Forms
- **Sign in**: Email format check + password ≥6 chars. On submit, show busy state for 600ms then route to `/dashboard`.
- **Sign up**: Name required; email format; password ≥8 chars; confirm matches. Show per-field error text in `var(--error)` color. On success → `/verify`.
- **Verify email**: 6 individual digit cells (mono, 1.4rem). Auto-focus next cell on input, auto-back on backspace when empty. When all 6 filled, wait 300ms then route to `/onboarding`.
- **Forgot**: Submit shows a "Sent" confirmation panel inline; doesn't navigate away.

### Camera permission flow (`/onboarding/camera`)
Three local states: `idle`, `granted`, `denied`. Idle shows the "Turn on camera" CTA. Granted shows success badge + continue button. Denied shows the recovery instructions ("Click the camera icon in the address bar…") plus "I've re-enabled it" (back to idle) and "Continue without camera" (skip to calibration). There's also a small "Simulate permission denied" link for testing — **remove this in production**.

### Practice loop (`/practice/:slug`)
See state transitions in the Practice section above. Auto-advance behavior: in the real product, the hand-pose model emits a match score 0–1. When it crosses a configurable threshold (settings: "Auto-advance after pass" — `off` / `camera` / `always`), the Continue action fires automatically. The mocked match overlay shows `±N% match` where N is a placeholder; replace with the live score.

### Pause / Exit
**Pause** freezes the camera preview and shows "paused" in the camera caption. **Exit** routes to `/dashboard`. No "are you sure" prompt — exiting is non-destructive (progress is per-rep, saved on every advance).

### Hover / focus
- Buttons: primary brightens `filter: brightness(1.08)` on hover; secondary swaps to `bg-elev` and accent-tinted border.
- Inputs: 1px accent border on focus + a 3px outer ring `var(--accent-bg)`.
- Cards (lesson cards, recent lessons): 1px accent ring + a slight lift via shadow on hover.
- Lesson rows in the catalog: background shifts to `bg-paper` and the right-arrow translates 4px right + colors to accent.

### Responsive breakpoints
- `≥1200px` default desktop
- `≤980px` recent-lessons grid drops to 2 columns
- `≤880px` two-column hero/intro/auth grids collapse to single column
- `≤780px` practice camera+reference stack
- `≤760px` mobile-first padding, nav links hide (navigation moves to the prototype-only screen index)
- `≤600px` 3-stage practice tabs stack; stats grid drops to 2 columns
- `≤520px` form pairs (password + confirm) stack

## State management

Most screens are stateless route components. The pieces that need real state in production:

- **Auth session** — user identity, JWT or session cookie. Inject from your auth provider.
- **Progress store** — for every (lesson_slug, sign, drill, rep, timestamp, pass_score). Drives dashboard heatmap, course progress (`38 / 75`), lesson card progress %, and mastery snapshot on `/complete`.
- **Streak counter** — derived from progress timestamps. Two "freeze tokens" tolerate missed days. Shown on dashboard and `/complete`.
- **Practice runtime** — current sign index, stage (0–2), rep (1–3), match score from the hand-pose model. Drives the Continue button label and the auto-advance behavior.
- **Settings** — stored locally (App preferences) and synced to account (Notifications, Account). All toggles in `/settings/app` should prefill the Lesson Intro toggles before practice starts.

## Design tokens — Foundry · Aurora (primary)

### Colors
| Token | Value | Use |
|-------|-------|-----|
| `--bg` | `#0f1a2e` | Page background |
| `--bg-paper` | `#1a2845` | Card / elevated surface |
| `--bg-elev` | `#213254` | Hover / input fill |
| `--bg-deep` | `#0a1322` | Deep wells (progress track, etc) |
| `--fg` | `#f1f5fb` | Primary text |
| `--fg-muted` | `#94a3b8` | Body text, secondary |
| `--fg-subtle` | `#64748b` | Captions, footnotes |
| `--fg-faint` | `#475569` | Disabled, leading numerals |
| `--line` | `rgba(241,245,251,0.14)` | Card borders, dividers |
| `--line-soft` | `rgba(241,245,251,0.07)` | Subtle dividers |
| `--accent` | `#22d3ee` | Cyan — links, focus rings, active states |
| `--accent-deep` | `#0891b2` | Hover variant |
| `--accent-soft` | `#67e8f9` | Light variant |
| `--accent-bg` | `rgba(34,211,238,0.12)` | Accent-tinted backgrounds |
| `--success` | `#34d399` | ✓ marks, success badges |
| `--error` | `#f87171` | Error text, danger button |
| `--warn` | `#fbbf24` | Warning badges, icons |

### Gradients
| Token | Value | Use |
|-------|-------|-----|
| `--grad-primary` | `linear-gradient(135deg, #67e8f9 0%, #22d3ee 40%, #a78bfa 100%)` | Primary buttons, gradient text fills, progress bars |
| `--grad-glow-a` | `radial-gradient(circle, rgba(34,211,238,0.30) 0%, transparent 55%)` | Hero top-right glow |
| `--grad-glow-b` | `radial-gradient(circle, rgba(167,139,250,0.22) 0%, transparent 55%)` | Hero bottom-left glow |
| `--grad-card` | `linear-gradient(180deg, rgba(34,211,238,0.06) 0%, rgba(167,139,250,0.04) 100%)` | Subtle card overlay |

### Typography
| Token | Value |
|-------|-------|
| Display | `"Inter", ui-sans-serif, system-ui, sans-serif` — weight 800, letter-spacing -0.025em, line-height 1.02 |
| Display alt | `"Archivo Black"` for the nav wordmark only |
| Body / UI / Mono | `"JetBrains Mono", ui-monospace, "SF Mono", monospace` — all body, captions, eyebrows, footnotes |

Type scale:
- `h-1`: clamp(2.6rem, 6vw, 5rem), weight 800
- `h-2`: clamp(1.6rem, 3vw, 2.4rem), weight 800
- `h-3`: 1.35rem, weight 700
- `h-4`: 1.1rem, weight 700
- `lede`: 0.96rem mono, color `--fg-muted`, line-height 1.7
- `body-prose`: 0.92rem mono, line-height 1.75
- `eyebrow`: 0.72rem mono, uppercase, letter-spacing 0.12em, color `--fg-muted`
- `footnote`: 0.76rem mono, color `--fg-subtle`

### Radii
| Token | Value |
|-------|-------|
| `--radius` | 6px (default) |
| `--radius-md` | 8px (inputs, segmented) |
| `--radius-lg` | 12px (cards, media) |
| `--radius-pill` | 999px (buttons, badges, chips) |

### Shadows
- `--shadow-card`: `0 1px 0 rgba(255,255,255,0.04) inset, 0 1px 2px rgba(0,0,0,0.4)`
- `--shadow-pop`: `0 8px 24px rgba(0,0,0,0.5), 0 24px 60px rgba(0,0,0,0.6)`
- Primary button gets `0 1px 0 rgba(255,255,255,0.18) inset, 0 8px 24px rgba(0,0,0,0.4)` for the gradient highlight

### Spacing scale (in use)
Increments of 4 / 8 / 12 / 14 / 16 / 18 / 20 / 24 / 28 / 32 / 40 / 48 / 64. No formal `--space-N` tokens were created; use the spacing values directly as documented in the per-screen layouts.

### Wordmark (striped stencil)
The "ASL PILOT" nav text uses a repeating-linear-gradient background-clipped to text:
```css
background: repeating-linear-gradient(
  180deg,
  var(--fg) 0 18%, transparent 18% 28%,
  var(--fg) 28% 46%, transparent 46% 56%,
  var(--fg) 56% 74%, transparent 74% 84%,
  var(--fg) 84% 100%
);
-webkit-background-clip: text;
background-clip: text;
color: transparent;
```
Pair with `font-family: "Archivo Black"`, `font-weight: 900`, `letter-spacing: 0.04em`, `text-transform: uppercase`.

### Brand mark (handshape glyph)
A simple SVG: a rounded square frame with a stylized fanned hand (four fingers + thumb). Source in `src/components.jsx` → `Brand` function. 28×28px in the nav. Color is `currentColor` so it adapts.

## Alternate palettes (Foundry only)

If the team wants color variation while staying in Foundry, swap `--bg`, `--bg-paper`, `--bg-elev`, `--bg-deep`, `--accent`, `--accent-deep`, `--accent-soft`, `--accent-bg`, and the three gradient tokens.

**Cobalt** — deeper, classic SB blue
```
--bg:#0c1426  --bg-paper:#152038  --accent:#3b82f6
--grad-primary: linear-gradient(135deg, #60a5fa, #3b82f6, #1d4ed8)
```

**Glacier** — lightest, mint-cyan
```
--bg:#172234  --bg-paper:#22324a  --accent:#5eead4
--grad-primary: linear-gradient(135deg, #99f6e4, #5eead4, #38bdf8)
```

**Ember** — sky blue to indigo
```
--bg:#0e1623  --bg-paper:#1a2438  --accent:#38bdf8
--grad-primary: linear-gradient(135deg, #7dd3fc, #38bdf8, #6366f1)
```

## Alternate directions (not selected)

The prototype includes three other directions. Implement these only if the team wants light-mode editorial alternatives:
- **Reader** — Newsreader serif, warm cream paper (#f1ead9), terracotta accent (#8b3a1f)
- **Field Manual** — IBM Plex Serif/Sans/Mono, dot-grid paper background, construction-orange accent (#c2410c), square corners
- **Studio** — Instrument Serif italic display, off-cream paper (#e8e2d2), forest-green accent (#2f4a3a), generous rounded radii

Tokens for all three are in `src/tokens.jsx` under their respective `:root[data-direction]` blocks.

## Assets

- **No final imagery yet.** Every media slot in the prototype is a placeholder: a diagonal-stripe panel (`media-ph`) with a mono caption indicating what should drop in. The product needs Deaf-instructor reference videos for each of the 75 signs.
- **Demonstrator credits** in the About page reference Maya R., Daniel V., Priya G., Jordan T. — these are placeholder names. Replace with actual signed credits from your demonstrators.
- **Logo / brand mark** — the rounded-square hand SVG in `src/components.jsx` `Brand()` is original to this prototype. The "ASL PILOT" striped wordmark is original (CSS-based, no asset file).
- **No third-party imagery** is used. No icon library — every icon is an inline SVG drawn from scratch (camera, search, check, X, network, etc.) in their respective screen files.

## Privacy & data — implementation note

Privacy copy on `/privacy` makes specific promises the implementation must honor:

1. **The hand-pose model runs in-browser.** No camera frames or hand-keypoint data is uploaded to the server. Recommend onnxruntime-web or MediaPipe Tasks JS.
2. **Practice telemetry** stored per rep: `{ lesson, sign, drill, timestamp, pass_score (0–1) }`. That's the maximum.
3. **No third-party analytics.** No GA, no Segment, no Posthog in the pilot.
4. **Two cookies only**: session + settings. Document exactly that.
5. **Export & delete.** Account settings must offer a JSON export of all stored progress + a delete action.

## Files (in this bundle)

- `ASL Pilot Redesign.html` — entry point. Loads React 18 + Babel standalone (in-browser transform — fine for prototype, **replace with a build step** in production).
- `src/tokens.jsx` — design tokens, all four directions, the four Foundry palettes, font injection. The single source of truth for visual style.
- `src/components.jsx` — Brand, Button, Field, Input, Toggle, Checkbox, Badge, Progress, Crumbs, Eyebrow/EyebrowLine, Rule, MediaPlaceholder. Recreate these as your codebase's component primitives.
- `src/layout.jsx` — Nav (authed + public), Footer, AppShell, AuthShell, MarketingShell. Replace the hash router (`useHashRoute`) with the codebase's router.
- `src/screens-public.jsx` — Landing, Sign in, Sign up, Forgot, Verify email.
- `src/screens-onboarding.jsx` — Welcome, Camera, Calibration, First-sign.
- `src/screens-main.jsx` — Dashboard, Lessons catalog, Lesson intro, Practice, Complete. **The `LESSONS` array at the top is the seed data.**
- `src/screens-secondary.jsx` — Settings (3), Privacy, Help, About, Camera-denied, Offline, 404, Designer notes.
- `src/app.jsx` — Router, Tweaks panel hookup, screen index overlay (proto-only chrome, remove in production), bootstrap.
- `src/tweaks-panel.jsx` — Prototype-only tweak UI for switching directions/palettes. Not part of the final product.

To preview the prototype locally before recreating: serve the folder over HTTP (e.g. `npx serve .`) and open `ASL Pilot Redesign.html`. Switch directions/palettes via the **Tweaks** button bottom-right. Browse the 23 screens via the dark pill bottom-left.

## Implementation checklist

A reasonable order of operations:

1. Set up the routing skeleton with empty pages for all 23 routes.
2. Port the design tokens (Foundry · Aurora only) to your styling layer (CSS vars, Tailwind config, Stitches theme, etc.).
3. Build the component primitives: Button (3 variants × 3 sizes), Field, Input, Toggle, Checkbox, Badge, Progress, Eyebrow, Rule.
4. Build the layout shells: PublicNav, AuthedNav (matches sign-in state), Footer.
5. Implement the hero — **Practice screen** — first. It exercises the most patterns.
6. Build Dashboard, Lessons catalog, Lesson intro, Lesson complete using the same primitives.
7. Build auth screens (Sign in, Sign up, Forgot, Verify).
8. Build onboarding flow with the camera permission state machine.
9. Build Settings, Privacy, Help, About, error states.
10. Wire the camera + hand-pose model. The prototype mocks this entirely; this is where the real engineering lives.
11. Remove all prototype-only chrome: the floating screen-index button, the designer-notes route, the tweaks panel, the "Simulate permission denied" link.

Estimated build effort for an experienced React developer: 2–3 weeks for UI parity, plus separate scope for the hand-pose model integration.
