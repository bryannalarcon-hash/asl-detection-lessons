// tokens.jsx — three design directions for ASL Pilot
// Each direction sets CSS custom properties on :root[data-direction="..."]
// Components consume var(--token) so swapping is instant.

const DIRECTIONS = {
  reader: {
    label: "Reader",
    blurb: "Classical academic press. Warm paper, transitional serif, footnote sidenotes.",
    fonts: ["Newsreader:opsz,wght@6..72,400;6..72,500;6..72,600;6..72,700", "JetBrains+Mono:wght@400;500"],
  },
  field: {
    label: "Field Manual",
    blurb: "Tufte / lab notebook. Dot-grid paper, slab serif, technical annotations.",
    fonts: ["IBM+Plex+Serif:wght@400;500;600;700", "IBM+Plex+Sans:wght@400;500;600;700", "IBM+Plex+Mono:wght@400;500"],
  },
  studio: {
    label: "Studio",
    blurb: "Contemporary editorial. Large display serif, asymmetric grid, generous space.",
    fonts: ["Instrument+Serif:ital@0;1", "Newsreader:opsz,wght@6..72,400;6..72,500;6..72,600", "JetBrains+Mono:wght@400;500"],
  },
  foundry: {
    label: "Foundry",
    blurb: "Superbuilders dark. Deep navy, electric blue, striped wordmark, monospace throughout.",
    fonts: ["JetBrains+Mono:wght@400;500;600;700", "Archivo+Black", "Inter:wght@600;700;800;900"],
  },
};

const TOKEN_CSS = `
/* Shared resets */
*,*::before,*::after{box-sizing:border-box}
html,body{margin:0;padding:0}
body{
  font-family:var(--font-body);
  background:var(--bg);
  color:var(--fg);
  font-size:16px;
  line-height:1.5;
  -webkit-font-smoothing:antialiased;
  text-rendering:optimizeLegibility;
  min-height:100vh;
}
a{color:inherit;text-decoration:none}
button{font:inherit;color:inherit;background:none;border:0;cursor:pointer;padding:0}
input,select,textarea{font:inherit;color:inherit}
img,svg{display:block;max-width:100%}

/* ── Reader ── classical press */
:root[data-direction="reader"]{
  --bg:#f1ead9;
  --bg-paper:#f7f1e1;
  --bg-elev:#fbf6e8;
  --bg-deep:#e8dfc8;
  --fg:#1b1611;
  --fg-muted:#5d564a;
  --fg-subtle:#8e8576;
  --fg-faint:#b5ac9c;
  --line:rgba(27,22,17,0.16);
  --line-soft:rgba(27,22,17,0.08);
  --accent:#8b3a1f;
  --accent-deep:#5c2614;
  --accent-soft:#c2715a;
  --accent-bg:rgba(139,58,31,0.08);
  --success:#3d6a3a;
  --error:#8b2a1f;
  --warn:#a06b1c;
  --radius:2px;
  --radius-md:3px;
  --radius-lg:4px;
  --radius-pill:999px;
  --font-display:"Newsreader",ui-serif,Georgia,"Times New Roman",serif;
  --font-body:"Newsreader",ui-serif,Georgia,serif;
  --font-ui:ui-sans-serif,system-ui,-apple-system,"Helvetica Neue",sans-serif;
  --font-mono:"JetBrains Mono",ui-monospace,"SF Mono",monospace;
  --shadow-card:0 1px 0 rgba(27,22,17,0.04);
  --shadow-pop:0 1px 2px rgba(27,22,17,0.08), 0 8px 24px rgba(27,22,17,0.12);
  --grid-deco:none;
}
:root[data-direction="reader"] body{font-feature-settings:"onum","liga","kern"}

/* ── Field Manual ── lab notebook */
:root[data-direction="field"]{
  --bg:#f6f3e6;
  --bg-paper:#fbf8ec;
  --bg-elev:#fefcf2;
  --bg-deep:#ece8d6;
  --fg:#0e1a2b;
  --fg-muted:#3e4d63;
  --fg-subtle:#6e7a8e;
  --fg-faint:#9ea8b8;
  --line:rgba(14,26,43,0.22);
  --line-soft:rgba(14,26,43,0.10);
  --accent:#c2410c;
  --accent-deep:#7c2d05;
  --accent-soft:#ea7a3a;
  --accent-bg:rgba(194,65,12,0.10);
  --success:#1f6e3d;
  --error:#b91c1c;
  --warn:#a16207;
  --radius:0px;
  --radius-md:0px;
  --radius-lg:2px;
  --radius-pill:0px;
  --font-display:"IBM Plex Serif",Georgia,serif;
  --font-body:"IBM Plex Sans",ui-sans-serif,system-ui,sans-serif;
  --font-ui:"IBM Plex Sans",ui-sans-serif,system-ui,sans-serif;
  --font-mono:"IBM Plex Mono",ui-monospace,monospace;
  --shadow-card:none;
  --shadow-pop:0 0 0 1px rgba(14,26,43,0.22), 4px 4px 0 rgba(14,26,43,0.06);
  --grid-deco:radial-gradient(rgba(14,26,43,0.10) 1px, transparent 1px);
}
:root[data-direction="field"] body{
  background-image:var(--grid-deco);
  background-size:18px 18px;
  background-position:0 0;
}

/* ── Foundry ── Superbuilders dark */
:root[data-direction="foundry"]{
  --bg:#08101c;
  --bg-paper:#0e1828;
  --bg-elev:#142136;
  --bg-deep:#050b15;
  --fg:#f1f5fb;
  --fg-muted:#94a3b8;
  --fg-subtle:#64748b;
  --fg-faint:#475569;
  --line:rgba(241,245,251,0.14);
  --line-soft:rgba(241,245,251,0.07);
  --accent:#4d9fff;
  --accent-deep:#2563eb;
  --accent-soft:#7fbaff;
  --accent-bg:rgba(77,159,255,0.12);
  --success:#34d399;
  --error:#f87171;
  --warn:#fbbf24;
  --radius:6px;
  --radius-md:8px;
  --radius-lg:12px;
  --radius-pill:999px;
  --font-display:"Archivo Black","Inter",ui-sans-serif,system-ui,sans-serif;
  --font-body:"JetBrains Mono",ui-monospace,"SF Mono",monospace;
  --font-ui:"JetBrains Mono",ui-monospace,monospace;
  --font-mono:"JetBrains Mono",ui-monospace,monospace;
  --shadow-card:0 1px 0 rgba(255,255,255,0.04) inset, 0 1px 2px rgba(0,0,0,0.4);
  --shadow-pop:0 8px 24px rgba(0,0,0,0.5), 0 24px 60px rgba(0,0,0,0.6);
  --grid-deco:none;
  --sky:linear-gradient(180deg,#0e1828 0%,#142136 100%);
}
:root[data-direction="foundry"] body{font-feature-settings:"calt" 0,"liga";background:var(--bg)}
:root[data-direction="foundry"] ::selection{background:var(--accent);color:#08101c}
:root[data-direction="foundry"] .h-1{font-family:"Inter",ui-sans-serif,sans-serif;font-weight:800;letter-spacing:-0.025em;line-height:1.02;font-size:clamp(2.6rem,6vw,5rem)}
:root[data-direction="foundry"] .h-2{font-family:"Inter",ui-sans-serif,sans-serif;font-weight:800;letter-spacing:-0.02em}
:root[data-direction="foundry"] .h-3{font-family:"Inter",ui-sans-serif,sans-serif;font-weight:700;letter-spacing:-0.01em}
:root[data-direction="foundry"] .h-4{font-family:"Inter",ui-sans-serif,sans-serif;font-weight:700}
:root[data-direction="foundry"] .lede{font-family:"JetBrains Mono",ui-monospace,monospace;font-size:0.96rem;line-height:1.7;color:var(--fg-muted)}
:root[data-direction="foundry"] .body-prose{font-family:"JetBrains Mono",ui-monospace,monospace;font-size:0.92rem;line-height:1.75;color:var(--fg-muted)}
:root[data-direction="foundry"] .label{font-family:"JetBrains Mono",ui-monospace,monospace;text-transform:uppercase;letter-spacing:0.08em;font-size:0.74rem}
:root[data-direction="foundry"] .footnote{font-family:"JetBrains Mono",ui-monospace,monospace;font-size:0.76rem;color:var(--fg-subtle)}
:root[data-direction="foundry"] .nav{background:var(--bg);border-bottom:1px solid var(--line-soft)}
:root[data-direction="foundry"] .nav-brand{font-family:"Archivo Black","Inter",sans-serif;font-weight:900;font-size:1.05rem;letter-spacing:0.04em;text-transform:uppercase;color:var(--fg)}
:root[data-direction="foundry"] .nav-brand>span:last-child{
  background:repeating-linear-gradient(180deg,var(--fg) 0 18%,transparent 18% 28%,var(--fg) 28% 46%,transparent 46% 56%,var(--fg) 56% 74%,transparent 74% 84%,var(--fg) 84% 100%);
  -webkit-background-clip:text;background-clip:text;color:transparent;
}
:root[data-direction="foundry"] a.info-link,
:root[data-direction="foundry"] .info-section a{text-decoration:underline;text-underline-offset:3px;color:var(--accent);font-family:"JetBrains Mono",ui-monospace,monospace}

/* ── Foundry palette variants ── */
:root[data-direction="foundry"][data-palette="cobalt"]{
  --bg:#0c1426;--bg-paper:#152038;--bg-elev:#1c2a4b;--bg-deep:#08101e;
  --accent:#3b82f6;--accent-deep:#1d4ed8;--accent-soft:#60a5fa;--accent-bg:rgba(59,130,246,0.12);
  --grad-primary:linear-gradient(135deg,#60a5fa 0%,#3b82f6 50%,#1d4ed8 100%);
  --grad-glow-a:radial-gradient(circle, rgba(59,130,246,0.28) 0%, transparent 55%);
  --grad-glow-b:radial-gradient(circle, rgba(99,102,241,0.18) 0%, transparent 55%);
  --grad-card:linear-gradient(180deg, rgba(59,130,246,0.06) 0%, rgba(59,130,246,0) 60%);
}
:root[data-direction="foundry"][data-palette="aurora"]{
  --bg:#0f1a2e;--bg-paper:#1a2845;--bg-elev:#213254;--bg-deep:#0a1322;
  --accent:#22d3ee;--accent-deep:#0891b2;--accent-soft:#67e8f9;--accent-bg:rgba(34,211,238,0.12);
  --grad-primary:linear-gradient(135deg,#67e8f9 0%,#22d3ee 40%,#a78bfa 100%);
  --grad-glow-a:radial-gradient(circle, rgba(34,211,238,0.30) 0%, transparent 55%);
  --grad-glow-b:radial-gradient(circle, rgba(167,139,250,0.22) 0%, transparent 55%);
  --grad-card:linear-gradient(180deg, rgba(34,211,238,0.06) 0%, rgba(167,139,250,0.04) 100%);
}
:root[data-direction="foundry"][data-palette="glacier"]{
  --bg:#172234;--bg-paper:#22324a;--bg-elev:#2c3e5a;--bg-deep:#11192a;
  --accent:#5eead4;--accent-deep:#14b8a6;--accent-soft:#99f6e4;--accent-bg:rgba(94,234,212,0.12);
  --grad-primary:linear-gradient(135deg,#99f6e4 0%,#5eead4 45%,#38bdf8 100%);
  --grad-glow-a:radial-gradient(circle, rgba(94,234,212,0.25) 0%, transparent 55%);
  --grad-glow-b:radial-gradient(circle, rgba(56,189,248,0.20) 0%, transparent 55%);
  --grad-card:linear-gradient(180deg, rgba(94,234,212,0.05) 0%, rgba(56,189,248,0.04) 100%);
}
:root[data-direction="foundry"][data-palette="ember"]{
  --bg:#0e1623;--bg-paper:#1a2438;--bg-elev:#22304a;--bg-deep:#0a1019;
  --accent:#38bdf8;--accent-deep:#0284c7;--accent-soft:#7dd3fc;--accent-bg:rgba(56,189,248,0.12);
  --grad-primary:linear-gradient(135deg,#7dd3fc 0%,#38bdf8 50%,#6366f1 100%);
  --grad-glow-a:radial-gradient(circle, rgba(56,189,248,0.26) 0%, transparent 55%);
  --grad-glow-b:radial-gradient(circle, rgba(99,102,241,0.20) 0%, transparent 55%);
  --grad-card:linear-gradient(180deg, rgba(56,189,248,0.06) 0%, rgba(99,102,241,0.04) 100%);
}

/* ── Foundry gradient applications (apply to all palettes via data-direction) ── */
:root[data-direction="foundry"] .btn-primary{
  background:var(--grad-primary,linear-gradient(135deg,var(--accent-soft),var(--accent),var(--accent-deep)));
  border:0;color:#08101c;font-weight:600;
  box-shadow:0 1px 0 rgba(255,255,255,0.18) inset, 0 8px 24px rgba(0,0,0,0.4);
}
:root[data-direction="foundry"] .btn-primary:hover{filter:brightness(1.08)}
:root[data-direction="foundry"] .btn-secondary{background:var(--bg-paper);border:1px solid var(--line);color:var(--fg)}
:root[data-direction="foundry"] .btn-secondary:hover{background:var(--bg-elev);border-color:var(--accent-soft)}
:root[data-direction="foundry"] .card{
  background:var(--bg-paper);
  background-image:var(--grad-card,none);
  border:1px solid var(--line-soft);
  box-shadow:0 1px 0 rgba(255,255,255,0.05) inset, 0 8px 32px rgba(0,0,0,0.3);
}
:root[data-direction="foundry"] .badge-accent{
  background:var(--grad-primary,var(--accent));
  color:#08101c;font-weight:600;
}
:root[data-direction="foundry"] .progress-bar{background:var(--grad-primary,var(--accent))}
:root[data-direction="foundry"] .snapshot-fill{background:var(--grad-primary,var(--accent))}
:root[data-direction="foundry"] .heat-sq.lvl-4{background:var(--grad-primary,var(--accent))}
:root[data-direction="foundry"] .practice-rep-num{
  background:var(--grad-primary,var(--accent));
  -webkit-background-clip:text;background-clip:text;color:transparent;
}
:root[data-direction="foundry"] .dash-streak-num{
  background:var(--grad-primary,var(--accent));
  -webkit-background-clip:text;background-clip:text;color:transparent;
}
:root[data-direction="foundry"] .landing-em{
  background:var(--grad-primary,var(--accent));
  -webkit-background-clip:text;background-clip:text;color:transparent;
}
:root[data-direction="foundry"] .complete-badge{background:var(--grad-primary,var(--accent));color:#08101c}
:root[data-direction="foundry"] .lesson-card:hover{border-color:transparent;background:var(--bg-paper);box-shadow:0 0 0 1px var(--accent), 0 8px 24px rgba(0,0,0,0.3)}
:root[data-direction="foundry"] .nav-links a.active{background:var(--accent-bg);color:var(--accent)}
:root[data-direction="foundry"] .input:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-bg)}
:root[data-direction="foundry"] .checkbox.on .checkbox-box,
:root[data-direction="foundry"] .toggle.on .toggle-track{background:var(--grad-primary,var(--accent));border-color:transparent}

/* ── Studio ── modern editorial */
:root[data-direction="studio"]{
  --bg:#e8e2d2;
  --bg-paper:#f1ebda;
  --bg-elev:#f6f1e1;
  --bg-deep:#ddd5c1;
  --fg:#1c1a15;
  --fg-muted:#5d564a;
  --fg-subtle:#8a8377;
  --fg-faint:#b5ad9d;
  --line:rgba(28,26,21,0.14);
  --line-soft:rgba(28,26,21,0.07);
  --accent:#2f4a3a;
  --accent-deep:#1b2e23;
  --accent-soft:#5d7567;
  --accent-bg:rgba(47,74,58,0.10);
  --success:#2f4a3a;
  --error:#7a2d1f;
  --warn:#8b5a1c;
  --radius:10px;
  --radius-md:14px;
  --radius-lg:22px;
  --radius-pill:999px;
  --font-display:"Instrument Serif",ui-serif,Georgia,serif;
  --font-body:ui-sans-serif,system-ui,-apple-system,"Helvetica Neue",sans-serif;
  --font-ui:ui-sans-serif,system-ui,-apple-system,sans-serif;
  --font-mono:"JetBrains Mono",ui-monospace,monospace;
  --shadow-card:0 1px 2px rgba(28,26,21,0.04), 0 8px 28px rgba(28,26,21,0.06);
  --shadow-pop:0 4px 12px rgba(28,26,21,0.08), 0 24px 60px rgba(28,26,21,0.12);
  --grid-deco:none;
}

/* shared typographic primitives */
.h-display{font-family:var(--font-display);font-weight:500;line-height:1.05;letter-spacing:-0.01em}
.h-1{font-family:var(--font-display);font-weight:500;font-size:clamp(2.4rem,5vw,4rem);line-height:1.1;letter-spacing:-0.015em;margin:0;text-wrap:pretty}
.h-2{font-family:var(--font-display);font-weight:500;font-size:clamp(1.6rem,3vw,2.4rem);line-height:1.15;letter-spacing:-0.01em;margin:0}
.h-3{font-family:var(--font-display);font-weight:500;font-size:1.35rem;line-height:1.2;margin:0}
.h-4{font-family:var(--font-display);font-weight:500;font-size:1.1rem;line-height:1.25;margin:0}
.eyebrow{font-family:var(--font-mono);font-size:0.72rem;letter-spacing:0.12em;text-transform:uppercase;color:var(--fg-muted)}
.eyebrow-accent{font-family:var(--font-mono);font-size:0.72rem;letter-spacing:0.12em;text-transform:uppercase;color:var(--accent)}
.body-prose{font-family:var(--font-body);font-size:1.05rem;line-height:1.6;color:var(--fg);max-width:62ch}
.mono{font-family:var(--font-mono);font-feature-settings:"calt" 0}
.lede{font-family:var(--font-body);font-size:1.15rem;line-height:1.5;color:var(--fg-muted);max-width:60ch}

/* Studio uses italic serif for display variant */
:root[data-direction="studio"] .h-1{font-weight:400;font-size:clamp(2.6rem,5.5vw,4.6rem);letter-spacing:-0.02em;line-height:1.05}
:root[data-direction="studio"] .h-2{font-weight:400}
:root[data-direction="reader"] .h-1{font-weight:600}
:root[data-direction="reader"] .h-2{font-weight:600}
:root[data-direction="field"] .h-1{font-weight:600;letter-spacing:-0.02em}
:root[data-direction="field"] .h-2{font-weight:600}

/* Reduce motion */
@media (prefers-reduced-motion: reduce){
  *,*::before,*::after{animation-duration:0.01ms!important;transition-duration:0.01ms!important}
}

/* Selection */
::selection{background:var(--accent);color:var(--bg)}

/* Containers */
.page{max-width:1200px;margin:0 auto;padding:0 24px}
.page-narrow{max-width:760px;margin:0 auto;padding:0 24px}
@media (min-width:768px){
  .page{padding:0 40px}
  .page-narrow{padding:0 40px}
}

/* Decorations per direction */
.rule{height:1px;background:var(--line);width:100%}
.rule-strong{height:1px;background:var(--fg);width:100%;opacity:0.9}
:root[data-direction="field"] .rule{background:repeating-linear-gradient(to right,var(--line) 0 4px,transparent 4px 8px);height:1px}
:root[data-direction="reader"] .rule-double{height:4px;border-top:1px solid var(--line);border-bottom:1px solid var(--line);background:transparent}

/* Helper layout */
.stack{display:flex;flex-direction:column}
.row{display:flex}
.center{display:flex;align-items:center;justify-content:center}
.between{display:flex;align-items:center;justify-content:space-between}
.spacer{flex:1}
`;

function injectFonts() {
  const families = new Set();
  Object.values(DIRECTIONS).forEach(d => d.fonts.forEach(f => families.add(f)));
  const href = `https://fonts.googleapis.com/css2?${[...families].map(f => `family=${f}`).join("&")}&display=swap`;
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = href;
  document.head.appendChild(link);
}

function injectTokenCSS() {
  if (document.getElementById("__tokens_css")) return;
  const s = document.createElement("style");
  s.id = "__tokens_css";
  s.textContent = TOKEN_CSS;
  document.head.appendChild(s);
}

Object.assign(window, { DIRECTIONS, TOKEN_CSS, injectFonts, injectTokenCSS });
