// components.jsx — shared primitives styled via CSS variables so they re-skin per direction.

const COMPONENT_CSS = `
/* ============ BUTTON ============ */
.btn{
  display:inline-flex;align-items:center;justify-content:center;gap:8px;
  font-family:var(--font-ui);font-weight:500;font-size:0.95rem;line-height:1;
  padding:0.75rem 1.25rem;border-radius:var(--radius-pill);
  border:1px solid transparent;cursor:pointer;
  transition:transform .12s ease,background .15s ease,border-color .15s ease,color .15s ease;
  white-space:nowrap;
}
.btn:active{transform:translateY(0.5px)}
.btn-primary{background:var(--accent);color:var(--bg-paper);border-color:var(--accent)}
.btn-primary:hover{background:var(--accent-deep);border-color:var(--accent-deep)}
.btn-secondary{background:transparent;color:var(--fg);border-color:var(--line)}
.btn-secondary:hover{border-color:var(--fg);background:var(--bg-elev)}
.btn-ghost{background:transparent;color:var(--fg-muted);padding:0.5rem 0.75rem}
.btn-ghost:hover{color:var(--fg);background:var(--bg-elev)}
.btn-quiet{background:var(--bg-elev);color:var(--fg);border-color:var(--line-soft)}
.btn-quiet:hover{background:var(--bg-deep)}
.btn-link{padding:0;color:var(--accent);text-decoration:underline;text-underline-offset:3px;border-radius:0}
.btn-link:hover{color:var(--accent-deep)}
.btn-sm{padding:0.5rem 0.85rem;font-size:0.85rem}
.btn-lg{padding:0.95rem 1.6rem;font-size:1rem}
.btn-block{display:flex;width:100%}

/* Field-manual override: square buttons with offset shadow on primary */
:root[data-direction="field"] .btn-primary{box-shadow:3px 3px 0 var(--fg)}
:root[data-direction="field"] .btn-primary:hover{transform:translate(1px,1px);box-shadow:2px 2px 0 var(--fg)}
:root[data-direction="field"] .btn-secondary{box-shadow:none;border-width:1px}
:root[data-direction="field"] .btn{border-radius:0}

/* Reader override: pill-less, sharper, with rule underline on link */
:root[data-direction="reader"] .btn{border-radius:2px}
:root[data-direction="reader"] .btn-primary{font-weight:600}
:root[data-direction="reader"] .btn-secondary{border-style:solid}

/* Studio override: soft rounded, generous */
:root[data-direction="studio"] .btn{border-radius:999px;padding:0.85rem 1.4rem}
:root[data-direction="studio"] .btn-sm{padding:0.55rem 1rem}

/* ============ FIELDS ============ */
.field{display:flex;flex-direction:column;gap:6px}
.field-row{display:flex;flex-direction:row;align-items:center;gap:12px}
.label{font-family:var(--font-ui);font-size:0.82rem;font-weight:500;color:var(--fg-muted);letter-spacing:0.01em}
.label-row{display:flex;align-items:baseline;justify-content:space-between;gap:8px}
.input{
  font-family:var(--font-body);font-size:1rem;line-height:1.4;
  padding:0.7rem 0.85rem;background:var(--bg-elev);color:var(--fg);
  border:1px solid var(--line);border-radius:var(--radius-md);
  outline:none;transition:border-color .15s ease,background .15s ease;
  width:100%;
}
.input:focus{border-color:var(--accent);background:var(--bg-paper)}
.input::placeholder{color:var(--fg-faint)}
:root[data-direction="field"] .input{border-radius:0;background:var(--bg-paper);border-style:solid;border-width:1px 1px 2px 1px}
:root[data-direction="field"] .input:focus{border-color:var(--accent);border-bottom-color:var(--accent)}
:root[data-direction="reader"] .input{background:var(--bg-paper);border-radius:2px;border-bottom-width:2px}
:root[data-direction="studio"] .input{border-radius:12px;background:var(--bg-paper)}

.help{font-size:0.8rem;color:var(--fg-subtle);font-family:var(--font-ui)}
.error-text{font-size:0.8rem;color:var(--error);font-family:var(--font-ui)}

/* ============ CARD ============ */
.card{
  background:var(--bg-paper);border:1px solid var(--line-soft);
  border-radius:var(--radius-lg);padding:24px;
  box-shadow:var(--shadow-card);
}
.card-flat{background:transparent;border:1px solid var(--line);padding:24px;border-radius:var(--radius-lg)}
.card-tight{padding:16px}
:root[data-direction="field"] .card{border-color:var(--line);border-width:1px;background:var(--bg-paper);border-radius:0}
:root[data-direction="field"] .card-flat{border-radius:0}
:root[data-direction="reader"] .card{background:var(--bg-paper);border-radius:2px}
:root[data-direction="studio"] .card{border-radius:22px;border-color:var(--line-soft);background:var(--bg-paper)}

/* ============ NAV ============ */
.nav{
  display:flex;align-items:center;justify-content:space-between;
  padding:18px 24px;gap:24px;
  border-bottom:1px solid var(--line-soft);
  background:var(--bg);
  position:sticky;top:0;z-index:50;
}
:root[data-direction="reader"] .nav{border-bottom-style:double;border-bottom-width:3px}
:root[data-direction="field"] .nav{border-bottom:1px solid var(--fg)}
.nav-brand{font-family:var(--font-display);font-weight:600;font-size:1.15rem;letter-spacing:-0.01em;display:inline-flex;align-items:center;gap:10px;white-space:nowrap}
:root[data-direction="studio"] .nav-brand{font-style:italic;font-weight:400;font-size:1.4rem}
.nav-brand-mark{width:28px;height:28px;display:inline-flex;align-items:center;justify-content:center}
.nav-links{display:flex;align-items:center;gap:6px;font-family:var(--font-ui)}
.nav-links a{padding:8px 12px;color:var(--fg-muted);font-size:0.92rem;border-radius:var(--radius-md);transition:color .15s,background .15s}
.nav-links a:hover{color:var(--fg);background:var(--bg-elev)}
.nav-links a.active{color:var(--fg)}
:root[data-direction="reader"] .nav-links a.active{box-shadow:inset 0 -2px 0 var(--accent)}
:root[data-direction="field"] .nav-links a.active{background:var(--fg);color:var(--bg-paper)}
:root[data-direction="studio"] .nav-links a.active{background:var(--accent-bg);color:var(--accent)}
.nav-meta{display:flex;align-items:center;gap:14px;font-family:var(--font-ui);font-size:0.88rem;color:var(--fg-muted)}
@media (max-width:760px){
  .nav-links{display:none}
  .nav-meta{font-size:0.8rem}
  .nav{padding:14px 16px}
}

/* ============ FOOTER ============ */
.footer{
  border-top:1px solid var(--line-soft);
  padding:32px 24px;margin-top:64px;
  display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:16px;
  font-family:var(--font-ui);font-size:0.84rem;color:var(--fg-subtle);
}
.footer-links{display:flex;gap:18px;flex-wrap:wrap}
.footer-links a:hover{color:var(--fg)}
.footer-mark{font-family:var(--font-mono);font-size:0.72rem;letter-spacing:0.08em;text-transform:uppercase}

/* ============ TOGGLE / CHECKBOX ============ */
.toggle{position:relative;display:inline-flex;align-items:center;gap:10px;cursor:pointer;user-select:none}
.toggle-track{width:38px;height:22px;background:var(--bg-deep);border:1px solid var(--line);border-radius:999px;position:relative;transition:background .15s}
.toggle-thumb{position:absolute;left:2px;top:2px;width:16px;height:16px;background:var(--bg-paper);border-radius:50%;transition:left .15s;box-shadow:0 1px 2px rgba(0,0,0,0.15)}
.toggle.on .toggle-track{background:var(--accent);border-color:var(--accent)}
.toggle.on .toggle-thumb{left:18px}
:root[data-direction="field"] .toggle-track{border-radius:0}
:root[data-direction="field"] .toggle-thumb{border-radius:0;background:var(--fg);width:16px;height:16px}
:root[data-direction="field"] .toggle.on .toggle-thumb{background:var(--bg-paper)}

.checkbox{display:inline-flex;align-items:center;gap:10px;cursor:pointer}
.checkbox-box{width:18px;height:18px;border:1.5px solid var(--line);border-radius:4px;display:inline-flex;align-items:center;justify-content:center;background:var(--bg-paper);flex-shrink:0}
.checkbox.on .checkbox-box{background:var(--accent);border-color:var(--accent)}
.checkbox.on .checkbox-box::after{content:"";width:6px;height:10px;border-right:2px solid var(--bg-paper);border-bottom:2px solid var(--bg-paper);transform:rotate(45deg);margin-top:-2px}
:root[data-direction="field"] .checkbox-box{border-radius:0;border-width:1.5px}

/* ============ BADGE ============ */
.badge{
  display:inline-flex;align-items:center;gap:6px;
  font-family:var(--font-mono);font-size:0.72rem;letter-spacing:0.08em;text-transform:uppercase;
  padding:4px 10px;border-radius:var(--radius-pill);
  background:var(--bg-elev);color:var(--fg-muted);border:1px solid var(--line-soft);
}
.badge-accent{background:var(--accent-bg);color:var(--accent);border-color:transparent}
.badge-success{background:rgba(61,106,58,0.10);color:var(--success);border-color:transparent}
.badge-warn{background:rgba(160,107,28,0.10);color:var(--warn);border-color:transparent}
:root[data-direction="field"] .badge{border-radius:0;border:1px solid var(--line);background:transparent}

/* ============ PROGRESS ============ */
.progress{display:block;height:6px;background:var(--bg-deep);border-radius:999px;overflow:hidden;width:100%}
.progress-bar{display:block;height:100%;background:var(--accent);transition:width .3s ease}
:root[data-direction="field"] .progress{border-radius:0;border:1px solid var(--line);height:8px}
:root[data-direction="field"] .progress-bar{border-radius:0}

/* ============ BREADCRUMB ============ */
.crumbs{font-family:var(--font-ui);font-size:0.82rem;color:var(--fg-subtle);display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.crumbs a:hover{color:var(--fg)}
.crumbs .sep{opacity:0.5}

/* ============ STEP INDICATOR ============ */
.steps{display:flex;align-items:center;gap:8px;font-family:var(--font-mono);font-size:0.78rem;letter-spacing:0.08em;text-transform:uppercase;color:var(--fg-muted)}
.steps .num{display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border:1px solid var(--line);border-radius:50%}
.steps .num.active{background:var(--accent);color:var(--bg-paper);border-color:var(--accent)}
.steps .num.done{background:var(--fg);color:var(--bg-paper);border-color:var(--fg)}
:root[data-direction="field"] .steps .num{border-radius:0}

/* ============ DECORATION: corner brackets for field manual ============ */
.bracket-frame{position:relative;padding:24px}
:root[data-direction="field"] .bracket-frame::before,
:root[data-direction="field"] .bracket-frame::after{
  content:"";position:absolute;width:14px;height:14px;border:1.5px solid var(--fg);
}
:root[data-direction="field"] .bracket-frame::before{top:0;left:0;border-right:0;border-bottom:0}
:root[data-direction="field"] .bracket-frame::after{bottom:0;right:0;border-left:0;border-top:0}

/* ============ NUMBERED SIDENOTE for reader ============ */
.sidenote{
  font-family:var(--font-body);font-size:0.86rem;line-height:1.5;color:var(--fg-muted);
  border-left:2px solid var(--accent);padding:6px 0 6px 14px;margin:8px 0;
}
:root[data-direction="reader"] .sidenote{font-style:italic}

/* ============ HERO eyebrow w/ rule ============ */
.eyebrow-line{display:flex;align-items:center;gap:12px;font-family:var(--font-mono);font-size:0.72rem;letter-spacing:0.14em;text-transform:uppercase;color:var(--fg-muted)}
.eyebrow-line .eyebrow-rule{display:block;width:32px;height:1px;background:var(--fg-muted);flex-shrink:0}
`;

// ── React components ──────────────────────────────────────────────

function Brand({ size = "md" }) {
  // Logo mark — a stylized hand shape in a frame, varies subtly per direction via CSS
  return (
    <span className="nav-brand">
      <span className="nav-brand-mark" aria-hidden="true">
        <svg viewBox="0 0 32 32" width="28" height="28" fill="none">
          <rect x="0.5" y="0.5" width="31" height="31" rx="3" stroke="currentColor" strokeOpacity="0.85" />
          <path d="M9 21V12.5a1.5 1.5 0 113 0V18m0 0V10.5a1.5 1.5 0 113 0V18m0 0V11.5a1.5 1.5 0 113 0V19m0 0v-5a1.5 1.5 0 113 0v6.5c0 3.5-2.5 6-6 6s-6-2.5-6-6V21" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </span>
      <span>ASL Pilot</span>
    </span>
  );
}

function Button({ children, variant = "primary", size = "md", as: As = "button", className = "", ...rest }) {
  const cls = `btn btn-${variant} ${size === "sm" ? "btn-sm" : size === "lg" ? "btn-lg" : ""} ${className}`.trim();
  return <As className={cls} {...rest}>{children}</As>;
}

function Field({ label, hint, error, htmlFor, action, children }) {
  return (
    <label className="field" htmlFor={htmlFor}>
      <span className="label-row">
        <span className="label">{label}</span>
        {action && <span>{action}</span>}
      </span>
      {children}
      {hint && !error && <span className="help">{hint}</span>}
      {error && <span className="error-text">{error}</span>}
    </label>
  );
}

function Input(props) {
  return <input className={`input ${props.className || ""}`.trim()} {...props} />;
}

function Toggle({ on, onChange, label }) {
  return (
    <button type="button" className={`toggle ${on ? "on" : ""}`} onClick={() => onChange(!on)} aria-pressed={on}>
      <span className="toggle-track"><span className="toggle-thumb" /></span>
      {label && <span style={{ fontFamily: "var(--font-ui)", fontSize: "0.92rem" }}>{label}</span>}
    </button>
  );
}

function Checkbox({ on, onChange, label }) {
  return (
    <button type="button" className={`checkbox ${on ? "on" : ""}`} onClick={() => onChange(!on)} aria-pressed={on}>
      <span className="checkbox-box" />
      {label && <span style={{ fontFamily: "var(--font-ui)", fontSize: "0.94rem" }}>{label}</span>}
    </button>
  );
}

function Badge({ children, variant = "" }) {
  return <span className={`badge ${variant ? `badge-${variant}` : ""}`.trim()}>{children}</span>;
}

function Progress({ value = 0, max = 100 }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return <span className="progress" role="progressbar" aria-valuenow={value} aria-valuemax={max}><span className="progress-bar" style={{ width: `${pct}%` }} /></span>;
}

function Crumbs({ items }) {
  return (
    <div className="crumbs">
      {items.map((it, i) => (
        <React.Fragment key={i}>
          {i > 0 && <span className="sep">/</span>}
          {it.href ? <a href={it.href} onClick={(e) => { e.preventDefault(); window.location.hash = it.href; }}>{it.label}</a> : <span>{it.label}</span>}
        </React.Fragment>
      ))}
    </div>
  );
}

function Eyebrow({ children, accent = false }) {
  return <div className={accent ? "eyebrow-accent" : "eyebrow"}>{children}</div>;
}

function EyebrowLine({ children }) {
  return <div className="eyebrow-line"><span className="eyebrow-rule" />{children}</div>;
}

function Rule({ variant = "" }) {
  return <div className={`rule ${variant ? `rule-${variant}` : ""}`.trim()} />;
}

// Placeholder for instructor video / imagery — direction-aware striped panel
function MediaPlaceholder({ label = "Deaf instructor — reference video", aspect = "16/9", subtle = false }) {
  return (
    <div className="media-ph" style={{ aspectRatio: aspect }} data-subtle={subtle}>
      <span className="media-ph-label">{label}</span>
    </div>
  );
}

const MEDIA_CSS = `
.media-ph{
  width:100%;border-radius:var(--radius-lg);overflow:hidden;position:relative;
  background:
    repeating-linear-gradient(45deg,var(--bg-deep) 0 10px,var(--bg-paper) 10px 20px);
  border:1px solid var(--line-soft);
  display:flex;align-items:flex-end;
}
.media-ph-label{
  font-family:var(--font-mono);font-size:0.72rem;letter-spacing:0.1em;text-transform:uppercase;
  color:var(--fg-muted);background:var(--bg-paper);padding:6px 10px;margin:12px;border:1px solid var(--line-soft);
}
:root[data-direction="field"] .media-ph{
  border-radius:0;background:var(--bg-paper);
  background-image:linear-gradient(var(--line) 1px,transparent 1px),linear-gradient(90deg,var(--line) 1px,transparent 1px);
  background-size:24px 24px;
}
:root[data-direction="field"] .media-ph-label{border-radius:0}
:root[data-direction="studio"] .media-ph{border-radius:22px}
:root[data-direction="foundry"] .media-ph{
  border-radius:12px;border:1px solid var(--line-soft);
  background:
    linear-gradient(135deg, rgba(77,159,255,0.06) 0%, rgba(77,159,255,0) 60%),
    repeating-linear-gradient(45deg, var(--bg-elev) 0 12px, var(--bg-paper) 12px 24px);
  position:relative;
}
:root[data-direction="foundry"] .media-ph::before{display:none}
:root[data-direction="foundry"] .media-ph-label{
  border-radius:4px;background:var(--bg);color:var(--fg-muted);
  border:1px solid var(--line-soft);
  font-family:"JetBrains Mono",monospace;
  position:relative;z-index:1;
}
`;

function injectComponentCSS() {
  if (document.getElementById("__components_css")) return;
  const s = document.createElement("style");
  s.id = "__components_css";
  s.textContent = COMPONENT_CSS + MEDIA_CSS;
  document.head.appendChild(s);
}

Object.assign(window, {
  Brand, Button, Field, Input, Toggle, Checkbox, Badge, Progress,
  Crumbs, Eyebrow, EyebrowLine, Rule, MediaPlaceholder, injectComponentCSS,
});
