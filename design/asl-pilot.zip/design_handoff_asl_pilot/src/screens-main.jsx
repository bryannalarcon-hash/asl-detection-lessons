// screens-main.jsx — dashboard, lessons catalog, lesson intro, practice, complete

const LESSONS = [
  { slug: "greetings", num: 1, title: "Greetings", count: 7, mins: 6, signs: ["HELLO","GOODBYE","HOW-ARE-YOU","FINE","PLEASE","THANK-YOU","SORRY"] },
  { slug: "numbers", num: 2, title: "Numbers 1–20", count: 7, mins: 8, signs: ["ONE","TWO","THREE","FIVE","TEN","FIFTEEN","TWENTY"] },
  { slug: "family", num: 3, title: "Family", count: 6, mins: 6, signs: ["MOTHER","FATHER","SISTER","BROTHER","FAMILY","HOME"] },
  { slug: "feelings", num: 4, title: "Feelings", count: 6, mins: 6, signs: ["HAPPY","SAD","TIRED","EXCITED","NERVOUS","CALM"] },
  { slug: "food", num: 5, title: "Food & drink", count: 6, mins: 7, signs: ["WATER","COFFEE","EAT","DRINK","HUNGRY","BREAD"] },
  { slug: "time", num: 6, title: "Time", count: 6, mins: 7, signs: ["TODAY","TOMORROW","YESTERDAY","NOW","LATER","TIME"] },
  { slug: "places", num: 7, title: "Places", count: 6, mins: 7, signs: ["HOME","SCHOOL","WORK","CITY","STORE","HOSPITAL"] },
  { slug: "verbs", num: 8, title: "Common verbs", count: 7, mins: 8, signs: ["GO","COME","HELP","WAIT","WORK","LEARN","KNOW"] },
  { slug: "questions", num: 9, title: "Question words", count: 6, mins: 6, signs: ["WHO","WHAT","WHERE","WHEN","WHY","HOW"] },
  { slug: "colors", num: 10, title: "Colors", count: 6, mins: 5, signs: ["RED","BLUE","GREEN","YELLOW","BLACK","WHITE"] },
  { slug: "animals", num: 11, title: "Animals", count: 6, mins: 6, signs: ["DOG","CAT","BIRD","FISH","HORSE","COW"] },
  { slug: "phrases", num: 12, title: "Everyday phrases", count: 6, mins: 7, signs: ["NICE-TO-MEET-YOU","SEE-YOU-LATER","TAKE-CARE","I-LOVE-YOU","GOOD-MORNING","GOOD-NIGHT"] },
];

const CATEGORIES = ["All","Greetings","Numbers","Family","Feelings","Food","Time","Places","Verbs","Questions","Colors","Animals","Phrases"];

// 75 days of activity, deterministic
function activityData() {
  const out = [];
  let seed = 7;
  for (let i = 0; i < 75; i++) {
    seed = (seed * 9301 + 49297) % 233280;
    const r = seed / 233280;
    out.push(r < 0.18 ? 0 : r < 0.45 ? 1 : r < 0.72 ? 2 : r < 0.92 ? 3 : 4);
  }
  // make most recent days lively
  for (let i = 70; i < 75; i++) out[i] = Math.max(out[i], 3);
  return out;
}

function DashboardScreen() {
  const [path] = useHashRoute();
  const heat = React.useMemo(() => activityData(), []);
  return (
    <AppShell path={path}>
      <div className="page dash">
        <header className="dash-head">
          <div>
            <Eyebrow>Dashboard · Spring term</Eyebrow>
            <h1 className="h-1 dash-title">Welcome back, Alex.</h1>
            <p className="lede" style={{ marginTop: 10 }}>You're 38 signs into the 75-sign pilot. A short session today will keep your streak.</p>
          </div>
          <div className="dash-streak">
            <span className="eyebrow">Streak</span>
            <div className="dash-streak-num h-display">04<span className="dash-streak-unit">days</span></div>
            <span className="footnote">2 freeze tokens available</span>
          </div>
        </header>

        <section className="dash-prog card">
          <div className="dash-prog-head">
            <Eyebrow>Course progress</Eyebrow>
            <span className="mono dash-prog-meta">38 / 75 signs</span>
          </div>
          <div className="dash-prog-bar"><Progress value={38} max={75} /></div>
          <div className="dash-prog-row">
            <div>
              <h3 className="h-3" style={{ marginBottom: 4 }}>Continue Lesson 5 · Food & drink</h3>
              <p className="footnote">You left off on <span style={{ color: "var(--fg)" }}>HUNGRY</span>, rep 2 of 3.</p>
            </div>
            <Button variant="primary" onClick={() => navigate("/lesson/food")}>Resume →</Button>
          </div>
        </section>

        <section className="dash-recent">
          <header className="dash-section-head">
            <Eyebrow>§ Recent lessons</Eyebrow>
            <a href="#/lessons" onClick={(e) => { e.preventDefault(); navigate("/lessons"); }} className="dash-section-link">Browse all twelve →</a>
          </header>
          <div className="dash-recent-grid">
            {[LESSONS[4], LESSONS[0], LESSONS[1], LESSONS[8]].map(l => (
              <LessonCard key={l.slug} lesson={l} progress={l.slug === "greetings" ? 1 : l.slug === "numbers" ? 0.57 : l.slug === "food" ? 0.33 : 0} />
            ))}
          </div>
        </section>

        <section className="dash-activity card">
          <header className="dash-activity-head">
            <div>
              <Eyebrow>§ Practice activity</Eyebrow>
              <h2 className="h-3" style={{ marginTop: 6 }}>Last seventy-five days</h2>
            </div>
            <div className="dash-activity-legend">
              <span>Less</span>
              {[0,1,2,3,4].map(n => <span key={n} className={`heat-sq lvl-${n}`} />)}
              <span>More</span>
            </div>
          </header>
          <div className="heat-grid">
            {heat.map((v, i) => (
              <span key={i} className={`heat-sq lvl-${v} ${i === 74 ? "today" : ""}`} title={`Day ${i+1}`} />
            ))}
          </div>
          <footer className="dash-activity-foot">
            <span className="footnote">Each square is one day. Color shows total reps. Click any day for a breakdown.</span>
          </footer>
        </section>
      </div>
    </AppShell>
  );
}

function LessonCard({ lesson, progress = 0 }) {
  return (
    <a className="lesson-card" href={`#/lesson/${lesson.slug}`} onClick={(e) => { e.preventDefault(); navigate(`/lesson/${lesson.slug}`); }}>
      <div className="lesson-card-num mono">№ {String(lesson.num).padStart(2, "0")}</div>
      <h3 className="h-4 lesson-card-title">{lesson.title}</h3>
      <div className="lesson-card-meta mono">{lesson.count} signs · {lesson.mins} min</div>
      {progress > 0 && (
        <div className="lesson-card-prog">
          <Progress value={progress * 100} max={100} />
          <span className="lesson-card-prog-num mono">{Math.round(progress * 100)}%</span>
        </div>
      )}
    </a>
  );
}

function LessonsCatalogScreen() {
  const [path] = useHashRoute();
  const [q, setQ] = React.useState("");
  const [cat, setCat] = React.useState("All");
  const filtered = LESSONS.filter(l => {
    if (cat !== "All" && !l.title.toLowerCase().includes(cat.toLowerCase().split(" ")[0])) return false;
    if (q && !l.title.toLowerCase().includes(q.toLowerCase()) && !l.signs.join(" ").toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  });
  return (
    <AppShell path={path}>
      <div className="page">
        <header className="cat-head">
          <Eyebrow>Catalog</Eyebrow>
          <h1 className="h-1">Twelve lessons. Seventy-five signs.</h1>
          <p className="lede" style={{ marginTop: 14 }}>Take them in any order. We recommend starting with Greetings — but if Numbers feels useful first, follow your curiosity.</p>
        </header>
        <div className="cat-controls">
          <div className="cat-search">
            <SearchIcon />
            <input className="cat-search-input" placeholder="Search lessons or signs…" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <div className="cat-chips">
            {CATEGORIES.map(c => (
              <button key={c} className={`cat-chip ${cat === c ? "active" : ""}`} onClick={() => setCat(c)}>{c}</button>
            ))}
          </div>
        </div>
        <div className="cat-grid">
          {filtered.length === 0 ? (
            <div className="cat-empty">
              <Eyebrow>Nothing here</Eyebrow>
              <p className="body-prose">No lessons match "{q}". Try a different word, or <button className="btn-link" onClick={() => { setQ(""); setCat("All"); }}>clear filters</button>.</p>
            </div>
          ) : filtered.map(l => <LessonRowCard key={l.slug} lesson={l} />)}
        </div>
      </div>
    </AppShell>
  );
}

function SearchIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="11" cy="11" r="7" />
      <path d="M21 21l-4.3-4.3" />
    </svg>
  );
}

function LessonRowCard({ lesson }) {
  return (
    <a className="lesson-row" href={`#/lesson/${lesson.slug}`} onClick={(e) => { e.preventDefault(); navigate(`/lesson/${lesson.slug}`); }}>
      <div className="lesson-row-num mono">№ {String(lesson.num).padStart(2, "0")}</div>
      <div className="lesson-row-body">
        <h3 className="h-3 lesson-row-title">{lesson.title}</h3>
        <p className="lesson-row-signs">{lesson.signs.slice(0, 4).map(s => <span key={s} className="lesson-row-sign">{s}</span>)}<span className="lesson-row-more">+{lesson.signs.length - 4} more</span></p>
      </div>
      <div className="lesson-row-meta mono">{lesson.count} signs<br/>~{lesson.mins} min</div>
      <span className="lesson-row-arrow">→</span>
    </a>
  );
}

function LessonIntroScreen({ slug }) {
  const [path] = useHashRoute();
  const lesson = LESSONS.find(l => l.slug === slug) || LESSONS[0];
  const [cam, setCam] = React.useState(true);
  const [ref, setRef] = React.useState(true);
  return (
    <AppShell path={path}>
      <div className="page intro">
        <Crumbs items={[{ label: "Lessons", href: "/lessons" }, { label: lesson.title }]} />
        <div className="intro-grid">
          <div className="intro-prose">
            <Eyebrow>Lesson № {String(lesson.num).padStart(2, "0")}</Eyebrow>
            <h1 className="h-1" style={{ marginTop: 10 }}>{lesson.title}</h1>
            <p className="lede" style={{ marginTop: 14 }}>
              {introBlurb(lesson.slug)}
            </p>

            <section className="intro-section">
              <Eyebrow>Signs you'll practice</Eyebrow>
              <ul className="intro-signs">
                {lesson.signs.map((s, i) => (
                  <li key={s}>
                    <span className="mono intro-sign-num">{String(i + 1).padStart(2, "0")}</span>
                    <span className="intro-sign-name">{s}</span>
                    <span className="intro-sign-rule" />
                    <span className="mono intro-sign-tag">3 reps</span>
                  </li>
                ))}
              </ul>
            </section>

            <section className="intro-section">
              <Eyebrow>About the demonstrators</Eyebrow>
              <p className="body-prose" style={{ marginTop: 8, fontSize: "0.96rem" }}>
                Reference videos in this lesson were filmed with <span style={{ color: "var(--fg)" }}>Maya R.</span> and <span style={{ color: "var(--fg)" }}>Daniel V.</span>, instructors at the Texas School for the Deaf in Austin.
              </p>
            </section>
          </div>
          <aside className="intro-panel">
            <div className="card">
              <Eyebrow>Practice settings</Eyebrow>
              <div className="stack" style={{ gap: 14, marginTop: 14 }}>
                <Checkbox on={cam} onChange={setCam} label="Camera on" />
                <Checkbox on={ref} onChange={setRef} label="Show instructor reference video" />
                <Rule />
                <p className="footnote">
                  Hiding the reference tests recall. Turning off the camera switches to self-report mode — you decide if your sign was correct.
                </p>
                <Button variant="primary" size="lg" onClick={() => navigate(`/practice/${lesson.slug}`)}>Start lesson →</Button>
                <Button variant="ghost" onClick={() => navigate("/lessons")}>← Back to catalog</Button>
              </div>
            </div>
            <div className="intro-aside-meta">
              <span><span className="eyebrow">Time</span> <span className="mono" style={{ color: "var(--fg)" }}>~{lesson.mins} min</span></span>
              <span><span className="eyebrow">Signs</span> <span className="mono" style={{ color: "var(--fg)" }}>{lesson.count}</span></span>
              <span><span className="eyebrow">Reps each</span> <span className="mono" style={{ color: "var(--fg)" }}>×3</span></span>
            </div>
          </aside>
        </div>
      </div>
    </AppShell>
  );
}

function introBlurb(slug) {
  const map = {
    greetings: "How conversations open and close. Begin every interaction here — hello, goodbye, asking how someone is.",
    numbers: "ASL numbers diverge from spelled-out English. We practice one through twenty, with the handshape conventions that trip up most beginners.",
    family: "The people in your life. Family signs are some of the most-used in casual conversation.",
    feelings: "Emotion words. We practice the sign and the facial register together, though only the sign is graded.",
    food: "Common food and drink words you'll use in a cafeteria, restaurant, or at home.",
    time: "When things happen. Today, tomorrow, yesterday — the spine of any plan.",
    places: "Where you go. Home, school, work, the major destinations of a typical day.",
    verbs: "Action words. Common motion verbs every beginner needs.",
    questions: "Who, what, where, when, why, how. ASL marks questions with the face too — we'll note this but won't grade it.",
    colors: "The basic palette. Useful for everyday description.",
    animals: "Common animal signs, mostly iconic and intuitive.",
    phrases: "Short multi-sign phrases you'll use daily. The bridge from vocabulary to conversation.",
  };
  return map[slug] || "Vocabulary practice for this lesson.";
}

function PracticeScreen({ slug }) {
  const lesson = LESSONS.find(l => l.slug === slug) || LESSONS[0];
  const [signIdx, setSignIdx] = React.useState(0);
  const [stage, setStage] = React.useState(0); // 0,1,2 = handshape, movement, sign
  const [rep, setRep] = React.useState(1);
  const [paused, setPaused] = React.useState(false);
  const [showHint, setShowHint] = React.useState(false);
  const [done, setDone] = React.useState(false);

  const currentSign = lesson.signs[signIdx];
  const stages = ["Handshape", "Movement", "Whole sign"];

  const advance = () => {
    if (stage < 2) return setStage(stage + 1);
    if (rep < 3) { setStage(0); return setRep(rep + 1); }
    // sign complete
    if (signIdx < lesson.signs.length - 1) {
      setSignIdx(signIdx + 1); setStage(0); setRep(1); setShowHint(false);
    } else {
      setDone(true);
      setTimeout(() => navigate(`/complete/${lesson.slug}`), 600);
    }
  };
  const back = () => {
    if (stage > 0) return setStage(stage - 1);
    if (rep > 1) { setStage(2); return setRep(rep - 1); }
    if (signIdx > 0) { setSignIdx(signIdx - 1); setStage(2); setRep(3); }
  };

  return (
    <div className="practice-shell">
      <header className="practice-head">
        <button className="practice-back" onClick={() => navigate(`/lesson/${lesson.slug}`)}>← Lesson · {lesson.title}</button>
        <div className="practice-head-meta">
          <span className="mono">Sign {signIdx + 1} of {lesson.signs.length}</span>
          <button className="btn-link" onClick={back}>↶ Back a drill</button>
          <button className="btn-link" onClick={() => setSignIdx(Math.max(0, signIdx - 1))}>↶ Back a sign</button>
          <span className="practice-divider" />
          <button className="btn btn-ghost btn-sm" onClick={() => setPaused(!paused)}>{paused ? "▶ Resume" : "‖ Pause"}</button>
          <button className="btn btn-ghost btn-sm" onClick={() => navigate("/dashboard")}>✕ Exit</button>
        </div>
      </header>

      <main className="practice-main page">
        <div className="practice-titlebar">
          <div>
            <Eyebrow>Now signing</Eyebrow>
            <h1 className="h-1 practice-word">{currentSign}</h1>
          </div>
          <div className="practice-rep">
            <Eyebrow>Rep</Eyebrow>
            <div className="practice-rep-num"><span className="mono">{rep}</span><span className="practice-rep-of mono">/ 3</span></div>
          </div>
        </div>

        <div className="practice-stages">
          {stages.map((s, i) => (
            <div key={s} className={`practice-stage ${i < stage ? "done" : i === stage ? "active" : ""}`}>
              <span className="mono practice-stage-num">{String(i + 1).padStart(2, "0")}</span>
              <span className="practice-stage-label">{s}</span>
              <span className="practice-stage-tick">{i < stage ? "✓" : ""}</span>
            </div>
          ))}
        </div>

        <div className="practice-grid">
          <figure className="practice-cell practice-cam">
            <figcaption className="practice-cap">
              <Eyebrow>Your camera</Eyebrow>
              <span className="practice-cap-meta mono">{paused ? "paused" : "live · on-device"}</span>
            </figcaption>
            <div className="practice-media">
              <MediaPlaceholder label={paused ? "Camera paused" : "Live preview"} aspect="4/3" />
              <div className="practice-overlay">
                <span className="practice-overlay-coords mono">±{Math.round(Math.random() * 30 + 60)}% match</span>
                <span className="practice-overlay-dot" />
              </div>
            </div>
          </figure>
          <figure className="practice-cell practice-ref">
            <figcaption className="practice-cap">
              <Eyebrow>Reference · {stages[stage]}</Eyebrow>
              <span className="practice-cap-meta mono">Maya R. · 0.5×</span>
            </figcaption>
            <div className="practice-media">
              <MediaPlaceholder label={`Reference · ${currentSign} · ${stages[stage]}`} aspect="4/3" />
              <div className="practice-ref-controls">
                <button title="Loop">↻</button>
                <button title="Slow">0.5×</button>
                <button title="Normal">1×</button>
              </div>
            </div>
          </figure>
        </div>

        <div className="practice-hint-row">
          {showHint ? (
            <div className="practice-hint">
              <Eyebrow accent>Hint</Eyebrow>
              <p className="body-prose" style={{ marginTop: 6, fontSize: "0.96rem" }}>
                {hintFor(currentSign, stage)}
              </p>
            </div>
          ) : (
            <button className="btn btn-quiet btn-sm" onClick={() => setShowHint(true)}>? Show a hint</button>
          )}
          <span className="spacer" />
          <Button variant="ghost" size="sm" onClick={() => { setStage(0); setRep(1); }}>Restart sign</Button>
        </div>

        <div className="practice-cta-row">
          <Button variant="ghost" onClick={() => setSignIdx(Math.min(lesson.signs.length - 1, signIdx + 1))}>Skip this sign →</Button>
          <Button variant="primary" size="lg" onClick={advance} disabled={done}>
            {done ? "Lesson complete ✓" : stage < 2 ? "Continue →" : rep < 3 ? `Next rep (${rep + 1} of 3) →` : signIdx < lesson.signs.length - 1 ? "Next sign →" : "Finish lesson ✓"}
          </Button>
        </div>
        <p className="footnote practice-foot">
          Tap continue when you're ready — or the camera will auto-advance once it detects a match.
        </p>
      </main>
    </div>
  );
}

function hintFor(sign, stage) {
  const stageHints = ["Get the handshape right first — fingers, thumb, palm orientation.", "Now the movement — direction, speed, repetition.", "Put it together — handshape and movement at conversational speed."];
  const wordHints = {
    HELLO: "Flat 'B' hand at the temple, like a salute. Swing the hand forward and away.",
    GOODBYE: "Open hand at chest height. Fingers wave to the receiver.",
    "THANK-YOU": "Flat hand at the chin. Move forward and slightly down toward the person.",
  };
  return `${wordHints[sign] || "Match the demonstrator as closely as you can."} ${stageHints[stage]}`;
}

function LessonCompleteScreen({ slug }) {
  const [path] = useHashRoute();
  const lesson = LESSONS.find(l => l.slug === slug) || LESSONS[0];
  const nextL = LESSONS[lesson.num] || LESSONS[0];
  return (
    <AppShell path={path}>
      <div className="page complete">
        <header className="complete-head">
          <div className="complete-badge">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="20 6 9 17 4 12" />
            </svg>
          </div>
          <div>
            <Eyebrow accent>Lesson complete</Eyebrow>
            <h1 className="h-1" style={{ marginTop: 8 }}>{lesson.title}.</h1>
            <p className="lede" style={{ marginTop: 10 }}>You signed {lesson.signs.length} new words. Spaced repetition will bring these back over the next few days.</p>
          </div>
        </header>

        <section className="complete-stats">
          <div className="complete-stat">
            <Eyebrow>Signs practiced</Eyebrow>
            <div className="h-display complete-stat-num">{lesson.signs.length}</div>
          </div>
          <div className="complete-stat">
            <Eyebrow>Total reps</Eyebrow>
            <div className="h-display complete-stat-num">{lesson.signs.length * 3}</div>
          </div>
          <div className="complete-stat">
            <Eyebrow>Time</Eyebrow>
            <div className="h-display complete-stat-num">{lesson.mins}<span style={{ fontSize: "0.5em", color: "var(--fg-muted)" }}> min</span></div>
          </div>
          <div className="complete-stat">
            <Eyebrow>Streak</Eyebrow>
            <div className="h-display complete-stat-num">5<span style={{ fontSize: "0.5em", color: "var(--fg-muted)" }}> days</span></div>
          </div>
        </section>

        <section className="complete-snapshot card">
          <Eyebrow>§ Mastery snapshot</Eyebrow>
          <div className="snapshot-grid">
            {lesson.signs.map((s, i) => (
              <div key={s} className="snapshot-row">
                <span className="mono snapshot-num">{String(i + 1).padStart(2, "0")}</span>
                <span className="snapshot-name">{s}</span>
                <span className="snapshot-bar"><span className="snapshot-fill" style={{ width: `${60 + ((i * 13) % 35)}%` }} /></span>
                <span className="mono snapshot-pct">{60 + ((i * 13) % 35)}%</span>
              </div>
            ))}
          </div>
          <p className="footnote" style={{ marginTop: 16 }}>
            Mastery is rough until you've practiced each sign three or four times. Come back tomorrow — review takes about three minutes.
          </p>
        </section>

        <div className="complete-cta">
          <Button variant="primary" size="lg" onClick={() => navigate(`/lesson/${nextL.slug}`)}>Continue to Lesson № {String(nextL.num).padStart(2, "0")} · {nextL.title} →</Button>
          <Button variant="secondary" onClick={() => navigate("/dashboard")}>Back to dashboard</Button>
        </div>
      </div>
    </AppShell>
  );
}

const SCREENS_MAIN_CSS = `
.dash{padding-top:32px}
.dash-head{display:flex;justify-content:space-between;align-items:flex-start;gap:24px;flex-wrap:wrap;margin-bottom:32px}
.dash-title{max-width:18ch;margin-top:8px}
.dash-streak{display:flex;flex-direction:column;align-items:flex-end;text-align:right;gap:4px}
.dash-streak-num{font-size:3rem;line-height:1;color:var(--accent);display:flex;align-items:baseline;gap:8px}
.dash-streak-unit{font-size:0.8rem;color:var(--fg-muted);font-family:var(--font-ui);letter-spacing:0.04em;text-transform:lowercase}
:root[data-direction="studio"] .dash-streak-num{font-style:italic}

.dash-prog{margin-bottom:40px}
.dash-prog-head{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:14px}
.dash-prog-bar{margin-bottom:18px}
.dash-prog-meta{font-size:0.84rem;color:var(--fg-muted)}
.dash-prog-row{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;padding-top:14px;border-top:1px solid var(--line-soft)}

.dash-section-head{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:16px}
.dash-section-link{font-family:var(--font-ui);font-size:0.88rem;color:var(--accent);text-decoration:underline;text-underline-offset:3px}
.dash-recent{margin-bottom:40px}
.dash-recent-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px}
@media (max-width:980px){.dash-recent-grid{grid-template-columns:repeat(2,1fr)}}
@media (max-width:520px){.dash-recent-grid{grid-template-columns:1fr}}

.lesson-card{display:flex;flex-direction:column;gap:8px;padding:18px;background:var(--bg-paper);border:1px solid var(--line-soft);border-radius:var(--radius-lg);transition:border-color .15s,transform .15s;color:inherit}
:root[data-direction="field"] .lesson-card{border-radius:0}
.lesson-card:hover{border-color:var(--line);transform:translateY(-1px)}
.lesson-card-num{font-size:0.74rem;color:var(--accent);letter-spacing:0.04em}
.lesson-card-title{margin:0}
.lesson-card-meta{font-size:0.78rem;color:var(--fg-subtle)}
.lesson-card-prog{display:flex;align-items:center;gap:10px;margin-top:6px}
.lesson-card-prog .progress{flex:1}
.lesson-card-prog-num{font-size:0.78rem;color:var(--fg-muted)}

.dash-activity-head{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;margin-bottom:20px;flex-wrap:wrap}
.dash-activity-legend{display:flex;align-items:center;gap:4px;font-family:var(--font-ui);font-size:0.78rem;color:var(--fg-subtle)}
.heat-grid{display:grid;grid-template-columns:repeat(15,1fr);gap:5px;margin-bottom:14px}
@media (max-width:600px){.heat-grid{grid-template-columns:repeat(10,1fr)}}
.heat-sq{display:block;aspect-ratio:1;border-radius:3px;background:var(--bg-deep)}
:root[data-direction="field"] .heat-sq{border-radius:0;border:1px solid var(--line-soft)}
.heat-sq.lvl-0{background:var(--bg-deep)}
.heat-sq.lvl-1{background:color-mix(in oklab, var(--accent) 25%, var(--bg-deep))}
.heat-sq.lvl-2{background:color-mix(in oklab, var(--accent) 50%, var(--bg-deep))}
.heat-sq.lvl-3{background:color-mix(in oklab, var(--accent) 75%, var(--bg-deep))}
.heat-sq.lvl-4{background:var(--accent)}
.heat-sq.today{outline:2px solid var(--fg);outline-offset:1px}
.dash-activity-foot{display:flex;justify-content:flex-start}

/* Catalog */
.cat-head{padding:32px 0 16px;max-width:60ch}
.cat-controls{display:flex;flex-direction:column;gap:14px;margin:20px 0 28px}
.cat-search{display:flex;align-items:center;gap:10px;background:var(--bg-paper);border:1px solid var(--line);padding:10px 14px;border-radius:var(--radius-md);max-width:480px}
:root[data-direction="field"] .cat-search{border-radius:0}
.cat-search-input{flex:1;background:transparent;border:0;outline:none;font:inherit;color:var(--fg);font-size:0.95rem}
.cat-chips{display:flex;gap:6px;flex-wrap:wrap}
.cat-chip{padding:6px 12px;border:1px solid var(--line);background:transparent;color:var(--fg-muted);border-radius:var(--radius-pill);font-family:var(--font-ui);font-size:0.85rem;cursor:pointer;transition:all .12s}
:root[data-direction="field"] .cat-chip{border-radius:0}
.cat-chip:hover{color:var(--fg);border-color:var(--fg)}
.cat-chip.active{background:var(--fg);color:var(--bg-paper);border-color:var(--fg)}
:root[data-direction="reader"] .cat-chip.active{background:var(--accent);border-color:var(--accent)}

.cat-grid{display:flex;flex-direction:column;gap:1px;background:var(--line-soft);border-top:1px solid var(--line);border-bottom:1px solid var(--line)}
.cat-empty{padding:48px 24px;background:var(--bg);text-align:center}
.lesson-row{display:grid;grid-template-columns:80px 1fr auto 32px;gap:24px;align-items:center;padding:24px 16px;background:var(--bg);transition:background .15s;color:inherit}
@media (max-width:700px){.lesson-row{grid-template-columns:60px 1fr;gap:14px;padding:16px}.lesson-row-meta,.lesson-row-arrow{display:none}}
.lesson-row:hover{background:var(--bg-paper)}
.lesson-row-num{font-size:0.84rem;color:var(--accent);letter-spacing:0.04em}
.lesson-row-title{margin:0}
.lesson-row-signs{margin:6px 0 0;display:flex;flex-wrap:wrap;gap:6px;font-family:var(--font-mono);font-size:0.74rem;color:var(--fg-subtle)}
.lesson-row-sign{padding:3px 8px;background:var(--bg-paper);border:1px solid var(--line-soft);letter-spacing:0.04em}
:root[data-direction="field"] .lesson-row-sign{border-radius:0}
.lesson-row-more{padding:3px 8px;color:var(--fg-faint)}
.lesson-row-meta{font-family:var(--font-mono);font-size:0.78rem;color:var(--fg-subtle);text-align:right;line-height:1.5}
.lesson-row-arrow{color:var(--fg-faint);font-size:1.2rem;transition:transform .15s,color .15s}
.lesson-row:hover .lesson-row-arrow{transform:translateX(4px);color:var(--accent)}

/* Lesson intro */
.intro{padding-top:24px}
.intro-grid{display:grid;grid-template-columns:1.4fr 1fr;gap:48px;margin-top:24px;align-items:start}
@media (max-width:880px){.intro-grid{grid-template-columns:1fr;gap:32px}}
.intro-section{margin-top:32px;padding-top:24px;border-top:1px solid var(--line-soft)}
.intro-signs{list-style:none;padding:0;margin:14px 0 0;display:flex;flex-direction:column;gap:0}
.intro-signs li{display:grid;grid-template-columns:36px 1fr auto auto;gap:14px;align-items:center;padding:10px 0;border-bottom:1px solid var(--line-soft)}
.intro-sign-num{color:var(--fg-faint);font-size:0.84rem}
.intro-sign-name{font-family:var(--font-display);font-size:1.05rem}
.intro-sign-rule{flex:1;height:1px;background:var(--line-soft)}
.intro-sign-tag{font-size:0.74rem;color:var(--fg-subtle)}
.intro-panel{position:sticky;top:96px;display:flex;flex-direction:column;gap:18px}
@media (max-width:880px){.intro-panel{position:static}}
.intro-aside-meta{display:flex;justify-content:space-between;gap:18px;padding:18px 4px;font-family:var(--font-ui);font-size:0.9rem;color:var(--fg)}
.intro-aside-meta>span{display:flex;flex-direction:column;gap:4px}

/* Practice */
.practice-shell{min-height:100vh;display:flex;flex-direction:column;background:var(--bg)}
.practice-head{display:flex;justify-content:space-between;align-items:center;padding:14px 24px;border-bottom:1px solid var(--line-soft);gap:24px;flex-wrap:wrap}
:root[data-direction="reader"] .practice-head{border-bottom-style:double;border-bottom-width:3px}
.practice-back{font-family:var(--font-ui);font-size:0.92rem;color:var(--fg-muted);background:none;border:0;cursor:pointer}
.practice-back:hover{color:var(--fg)}
.practice-head-meta{display:flex;align-items:center;gap:14px;flex-wrap:wrap;font-family:var(--font-ui);font-size:0.85rem;color:var(--fg-muted)}
.practice-head-meta .mono{color:var(--fg);font-size:0.78rem}
.practice-divider{width:1px;height:18px;background:var(--line)}
.practice-main{padding:32px 24px 64px;flex:1;max-width:1240px;margin:0 auto;width:100%}
.practice-titlebar{display:flex;justify-content:space-between;align-items:flex-end;gap:32px;margin-bottom:24px;flex-wrap:wrap}
.practice-word{font-size:clamp(3rem,7vw,5.5rem);line-height:0.95;letter-spacing:-0.02em;text-transform:lowercase;font-feature-settings:"smcp"}
:root[data-direction="reader"] .practice-word{text-transform:uppercase;letter-spacing:0;font-feature-settings:normal}
:root[data-direction="field"] .practice-word{text-transform:uppercase;letter-spacing:-0.01em}
.practice-rep{display:flex;flex-direction:column;align-items:flex-end;gap:4px}
.practice-rep-num{font-family:var(--font-display);font-size:2.4rem;line-height:1;color:var(--accent);display:flex;align-items:baseline;gap:6px}
.practice-rep-of{font-size:1.2rem;color:var(--fg-muted)}

.practice-stages{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:28px}
@media (max-width:600px){.practice-stages{grid-template-columns:1fr;gap:8px}}
.practice-stage{display:grid;grid-template-columns:auto 1fr auto;gap:12px;align-items:center;padding:14px 16px;border:1px solid var(--line-soft);border-radius:var(--radius-md);color:var(--fg-muted);font-family:var(--font-ui)}
:root[data-direction="field"] .practice-stage{border-radius:0}
.practice-stage.active{border-color:var(--accent);background:var(--accent-bg);color:var(--accent)}
.practice-stage.done{border-color:var(--line);color:var(--fg)}
.practice-stage-num{font-family:var(--font-mono);font-size:0.78rem;color:var(--fg-faint)}
.practice-stage.active .practice-stage-num{color:var(--accent)}
.practice-stage-label{font-size:0.96rem;font-weight:500}
.practice-stage-tick{color:var(--success);font-size:1rem;width:18px;text-align:right}

.practice-grid{display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:24px}
@media (max-width:780px){.practice-grid{grid-template-columns:1fr}}
.practice-cell{margin:0;display:flex;flex-direction:column;gap:10px}
.practice-cap{display:flex;justify-content:space-between;align-items:baseline}
.practice-cap-meta{font-size:0.72rem;color:var(--fg-subtle)}
.practice-media{position:relative}
.practice-overlay{position:absolute;top:14px;right:14px;display:flex;align-items:center;gap:10px;padding:6px 12px;background:rgba(27,22,17,0.65);color:var(--bg-paper);border-radius:var(--radius-pill);font-size:0.78rem;backdrop-filter:blur(8px)}
:root[data-direction="field"] .practice-overlay{border-radius:0;background:var(--fg)}
.practice-overlay-dot{width:8px;height:8px;border-radius:50%;background:var(--success);box-shadow:0 0 0 4px rgba(61,106,58,0.3);animation:pulse 1.4s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.5}}
.practice-ref-controls{position:absolute;bottom:14px;left:14px;display:flex;gap:4px;padding:4px;background:rgba(27,22,17,0.65);border-radius:var(--radius-pill);backdrop-filter:blur(8px)}
:root[data-direction="field"] .practice-ref-controls{border-radius:0;background:var(--fg)}
.practice-ref-controls button{padding:4px 10px;background:transparent;border:0;color:var(--bg-paper);font-family:var(--font-mono);font-size:0.78rem;cursor:pointer;border-radius:var(--radius-pill)}
:root[data-direction="field"] .practice-ref-controls button{border-radius:0}
.practice-ref-controls button:hover{background:rgba(255,255,255,0.18)}

.practice-hint-row{display:flex;align-items:flex-start;gap:16px;margin:24px 0;padding:16px 0;border-top:1px solid var(--line-soft);border-bottom:1px solid var(--line-soft);flex-wrap:wrap}
.practice-hint{flex:1;min-width:0;background:var(--accent-bg);padding:14px 18px;border-left:3px solid var(--accent);border-radius:var(--radius-md)}
:root[data-direction="field"] .practice-hint{border-radius:0;border-left-width:4px}

.practice-cta-row{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;margin-top:24px}
.practice-foot{margin-top:14px;text-align:center}

/* Complete */
.complete{padding-top:32px}
.complete-head{display:flex;gap:24px;align-items:flex-start;margin-bottom:48px}
.complete-badge{width:56px;height:56px;border-radius:50%;background:var(--success);color:var(--bg-paper);display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:4px}
:root[data-direction="field"] .complete-badge{border-radius:0}
.complete-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:32px}
@media (max-width:760px){.complete-stats{grid-template-columns:repeat(2,1fr)}}
.complete-stat{padding:18px;background:var(--bg-paper);border:1px solid var(--line-soft);border-radius:var(--radius-md);display:flex;flex-direction:column;gap:8px}
:root[data-direction="field"] .complete-stat{border-radius:0}
.complete-stat-num{font-size:2.6rem;color:var(--fg);line-height:1;display:flex;align-items:baseline;gap:6px}
:root[data-direction="studio"] .complete-stat-num{font-style:italic}

.complete-snapshot{margin-bottom:32px}
.snapshot-grid{display:flex;flex-direction:column;gap:0;margin-top:16px}
.snapshot-row{display:grid;grid-template-columns:36px 1fr 1.2fr 48px;gap:14px;align-items:center;padding:10px 0;border-bottom:1px solid var(--line-soft)}
@media (max-width:600px){.snapshot-row{grid-template-columns:32px 1fr 48px;}.snapshot-bar{display:none}}
.snapshot-num{color:var(--fg-faint);font-size:0.82rem}
.snapshot-name{font-family:var(--font-display);font-size:1rem}
.snapshot-bar{height:6px;background:var(--bg-deep);border-radius:999px;overflow:hidden}
:root[data-direction="field"] .snapshot-bar{border-radius:0;border:1px solid var(--line-soft)}
.snapshot-fill{display:block;height:100%;background:var(--accent)}
.snapshot-pct{font-size:0.82rem;color:var(--fg-muted);text-align:right}

.complete-cta{display:flex;gap:12px;flex-wrap:wrap}
`;

function injectScreensMainCSS() {
  if (document.getElementById("__screens_main_css")) return;
  const s = document.createElement("style");
  s.id = "__screens_main_css";
  s.textContent = SCREENS_MAIN_CSS;
  document.head.appendChild(s);
}

Object.assign(window, {
  LESSONS,
  DashboardScreen, LessonsCatalogScreen, LessonIntroScreen, PracticeScreen, LessonCompleteScreen,
  LessonCard, LessonRowCard,
  injectScreensMainCSS,
});
