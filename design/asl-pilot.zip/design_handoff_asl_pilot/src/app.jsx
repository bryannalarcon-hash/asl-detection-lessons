// app.jsx — router, tweaks panel, screen index

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "direction": "foundry",
  "foundryPalette": "aurora",
  "showIndex": false
}/*EDITMODE-END*/;

const FOUNDRY_PALETTES = {
  cobalt:  { label: "Cobalt",  swatch: ["#60a5fa","#3b82f6","#1d4ed8"] },
  aurora:  { label: "Aurora",  swatch: ["#67e8f9","#22d3ee","#a78bfa"] },
  glacier: { label: "Glacier", swatch: ["#99f6e4","#5eead4","#38bdf8"] },
  ember:   { label: "Ember",   swatch: ["#7dd3fc","#38bdf8","#6366f1"] },
};

const SCREEN_INDEX = [
  { group: "Public", items: [
    { to: "/", label: "01 · Landing" },
    { to: "/signin", label: "02 · Sign in" },
    { to: "/signup", label: "03 · Sign up" },
    { to: "/forgot", label: "04 · Forgot password" },
    { to: "/verify", label: "05 · Verify email" },
  ]},
  { group: "Onboarding", items: [
    { to: "/onboarding", label: "06 · Welcome" },
    { to: "/onboarding/camera", label: "07 · Camera" },
    { to: "/onboarding/calibrate", label: "08 · Calibration" },
    { to: "/onboarding/first-sign", label: "09 · First sign" },
  ]},
  { group: "App", items: [
    { to: "/dashboard", label: "10 · Dashboard" },
    { to: "/lessons", label: "11 · Lessons catalog" },
    { to: "/lesson/greetings", label: "12 · Lesson intro" },
    { to: "/practice/greetings", label: "13 · Practice loop" },
    { to: "/complete/greetings", label: "14 · Lesson complete" },
  ]},
  { group: "Settings & info", items: [
    { to: "/settings/account", label: "15 · Settings · account" },
    { to: "/settings/app", label: "16 · Settings · app" },
    { to: "/settings/notifications", label: "17 · Settings · notifications" },
    { to: "/privacy", label: "18 · Privacy" },
    { to: "/help", label: "19 · Help" },
    { to: "/about", label: "20 · About & credits" },
  ]},
  { group: "Errors", items: [
    { to: "/error/camera", label: "21 · Camera denied" },
    { to: "/error/offline", label: "22 · Offline" },
    { to: "/404", label: "23 · 404 not found" },
  ]},
  { group: "Meta", items: [
    { to: "/notes", label: "✶ Designer notes (eval)" },
  ]},
];

function Router({ path }) {
  // Public
  if (path === "/" || path === "") return <LandingScreen />;
  if (path === "/signin") return <SignInScreen />;
  if (path === "/signup") return <SignUpScreen />;
  if (path === "/forgot") return <ForgotScreen />;
  if (path === "/verify") return <VerifyEmailScreen />;
  // Onboarding
  if (path === "/onboarding") return <WelcomeStep />;
  if (path === "/onboarding/camera") return <CameraStep />;
  if (path === "/onboarding/calibrate") return <CalibrationStep />;
  if (path === "/onboarding/first-sign") return <FirstSignStep />;
  // App
  if (path === "/dashboard") return <DashboardScreen />;
  if (path === "/lessons") return <LessonsCatalogScreen />;
  if (path.startsWith("/lesson/")) return <LessonIntroScreen slug={path.split("/")[2]} />;
  if (path.startsWith("/practice/")) return <PracticeScreen slug={path.split("/")[2]} />;
  if (path.startsWith("/complete/")) return <LessonCompleteScreen slug={path.split("/")[2]} />;
  // Settings & info
  if (path === "/settings" || path === "/settings/account") return <SettingsAccountScreen />;
  if (path === "/settings/app") return <SettingsAppScreen />;
  if (path === "/settings/notifications") return <SettingsNotificationsScreen />;
  if (path === "/privacy") return <PrivacyScreen />;
  if (path === "/help") return <HelpScreen />;
  if (path === "/about") return <AboutScreen />;
  // Errors
  if (path === "/error/camera") return <CameraDeniedScreen />;
  if (path === "/error/offline") return <OfflineScreen />;
  // Meta
  if (path === "/notes") return <DesignerNotesScreen />;
  // Fallback
  return <NotFoundScreen />;
}

function ScreenIndex({ path, onClose }) {
  return (
    <div className="screen-index" onClick={onClose}>
      <aside className="screen-index-panel" onClick={(e) => e.stopPropagation()}>
        <header className="screen-index-head">
          <div>
            <Eyebrow accent>Prototype index</Eyebrow>
            <h3 className="h-3" style={{ marginTop: 6 }}>Jump to any screen</h3>
          </div>
          <button className="screen-index-close" onClick={onClose}>✕</button>
        </header>
        <div className="screen-index-body">
          {SCREEN_INDEX.map(g => (
            <section key={g.group}>
              <Eyebrow>{g.group}</Eyebrow>
              <ul className="screen-index-list">
                {g.items.map(it => (
                  <li key={it.to}>
                    <a href={`#${it.to}`} onClick={(e) => { e.preventDefault(); navigate(it.to); onClose(); }}
                       className={path.startsWith(it.to) && it.to !== "/" || path === it.to ? "active" : ""}>{it.label}</a>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
        <footer className="screen-index-foot">
          <span className="footnote">Switch design direction in the <span className="mono" style={{ color: "var(--accent)" }}>Tweaks</span> panel.</span>
        </footer>
      </aside>
    </div>
  );
}

function FloatingNav({ path, onIndex }) {
  return (
    <button className="floating-index-btn" onClick={onIndex} title="Open screen index">
      <span className="mono">{currentScreenLabel(path)}</span>
      <span className="floating-index-icon">⌘</span>
    </button>
  );
}

function currentScreenLabel(path) {
  for (const g of SCREEN_INDEX) {
    for (const it of g.items) {
      if (it.to === "/" && path === "/") return it.label;
      if (it.to !== "/" && path.startsWith(it.to)) return it.label;
    }
  }
  return "✶ unknown screen";
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [path] = useHashRoute();
  const [indexOpen, setIndexOpen] = React.useState(false);

  // Apply direction + palette to <html>
  React.useEffect(() => {
    document.documentElement.setAttribute("data-direction", t.direction || "studio");
    document.documentElement.setAttribute("data-palette", t.foundryPalette || "aurora");
  }, [t.direction, t.foundryPalette]);

  // Scroll to top on route change
  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [path]);

  return (
    <React.Fragment>
      <Router path={path} />
      <FloatingNav path={path} onIndex={() => setIndexOpen(true)} />
      {indexOpen && <ScreenIndex path={path} onClose={() => setIndexOpen(false)} />}
      <TweaksPanel title="Tweaks">
        <TweakSection label="Design direction" />
        <DirectionPicker value={t.direction} onChange={(v) => setTweak("direction", v)} />
        {t.direction === "foundry" && (
          <React.Fragment>
            <TweakSection label="Foundry palette" />
            <PalettePicker value={t.foundryPalette} onChange={(v) => setTweak("foundryPalette", v)} />
          </React.Fragment>
        )}
        <TweakSection label="Prototype" />
        <TweakButton label="Open screen index" onClick={() => setIndexOpen(true)}>Browse 23 screens</TweakButton>
        <TweakButton label="Designer notes (eval)" onClick={() => navigate("/notes")}>Read critique</TweakButton>
      </TweaksPanel>
    </React.Fragment>
  );
}

function DirectionPicker({ value, onChange }) {
  return (
    <div className="dir-picker">
      {Object.entries(DIRECTIONS).map(([k, d]) => (
        <button key={k} className={`dir-card ${value === k ? "active" : ""}`} onClick={() => onChange(k)}>
          <span className="dir-card-label">{d.label}</span>
          <span className="dir-card-blurb">{d.blurb}</span>
        </button>
      ))}
    </div>
  );
}

function PalettePicker({ value, onChange }) {
  return (
    <div className="pal-picker">
      {Object.entries(FOUNDRY_PALETTES).map(([k, p]) => (
        <button key={k} className={`pal-card ${value === k ? "active" : ""}`} onClick={() => onChange(k)}>
          <span className="pal-swatch" style={{ background: `linear-gradient(135deg, ${p.swatch.join(", ")})` }} />
          <span className="pal-label">{p.label}</span>
        </button>
      ))}
    </div>
  );
}

const APP_CSS = `
.floating-index-btn{
  position:fixed;left:16px;bottom:16px;z-index:2147483645;
  display:inline-flex;align-items:center;gap:10px;
  padding:8px 14px;background:rgba(27,22,17,0.85);color:#f1ead9;
  border:1px solid rgba(255,255,255,0.12);border-radius:999px;
  font-family:"JetBrains Mono",ui-monospace,monospace;font-size:0.74rem;
  letter-spacing:0.04em;backdrop-filter:blur(12px);cursor:pointer;
  box-shadow:0 8px 24px rgba(0,0,0,0.18);
}
.floating-index-btn:hover{background:rgba(27,22,17,0.95)}
.floating-index-icon{opacity:0.6;font-size:0.86rem}

.screen-index{position:fixed;inset:0;z-index:2147483647;display:flex;justify-content:flex-start;background:rgba(20,16,12,0.45);backdrop-filter:blur(2px)}
.screen-index-panel{width:min(360px,90vw);background:var(--bg);height:100vh;display:flex;flex-direction:column;border-right:1px solid var(--line);overflow:hidden;animation:slideIn .18s ease}
@keyframes slideIn{from{transform:translateX(-100%)}to{transform:translateX(0)}}
.screen-index-head{padding:20px 24px;display:flex;justify-content:space-between;align-items:flex-start;border-bottom:1px solid var(--line-soft);gap:16px}
.screen-index-close{font-size:1rem;color:var(--fg-muted);width:28px;height:28px;border-radius:50%;background:var(--bg-paper);cursor:pointer}
.screen-index-close:hover{color:var(--fg);background:var(--bg-deep)}
.screen-index-body{flex:1;overflow-y:auto;padding:20px 24px;display:flex;flex-direction:column;gap:28px}
.screen-index-list{list-style:none;padding:0;margin:10px 0 0;display:flex;flex-direction:column;gap:1px}
.screen-index-list a{display:block;padding:8px 0;font-family:var(--font-ui);font-size:0.92rem;color:var(--fg-muted);border-bottom:1px solid var(--line-soft);transition:color .12s}
.screen-index-list a:hover{color:var(--fg)}
.screen-index-list a.active{color:var(--accent)}
.screen-index-foot{padding:16px 24px;border-top:1px solid var(--line-soft);background:var(--bg-paper)}

.dir-picker{display:flex;flex-direction:column;gap:6px}
.dir-card{display:flex;flex-direction:column;align-items:flex-start;gap:4px;padding:10px 12px;background:var(--bg-paper);border:1px solid var(--line-soft);border-radius:8px;cursor:pointer;text-align:left;font:inherit;color:inherit;transition:border-color .15s,background .15s}
.dir-card:hover{border-color:var(--line)}
.dir-card.active{border-color:var(--accent);background:var(--accent-bg)}
.dir-card-label{font-family:var(--font-display);font-weight:600;font-size:0.96rem}
.dir-card-blurb{font-family:var(--font-ui);font-size:0.78rem;color:var(--fg-muted);line-height:1.4}
.dir-card.active .dir-card-blurb{color:var(--fg-muted)}

.pal-picker{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.pal-card{display:flex;align-items:center;gap:10px;padding:8px 10px;background:var(--bg-paper);border:1px solid var(--line-soft);border-radius:8px;cursor:pointer;text-align:left;font:inherit;color:inherit;transition:border-color .15s,background .15s}
.pal-card:hover{border-color:var(--line)}
.pal-card.active{border-color:var(--accent);background:var(--accent-bg)}
.pal-swatch{display:block;width:24px;height:24px;border-radius:6px;flex-shrink:0;box-shadow:0 0 0 1px rgba(0,0,0,0.08) inset}
.pal-label{font-family:var(--font-ui);font-size:0.84rem;color:var(--fg)}
`;

function injectAppCSS() {
  if (document.getElementById("__app_css")) return;
  const s = document.createElement("style");
  s.id = "__app_css";
  s.textContent = APP_CSS;
  document.head.appendChild(s);
}

function bootstrap() {
  injectFonts();
  injectTokenCSS();
  injectComponentCSS();
  injectLayoutCSS();
  injectScreensPublicCSS();
  injectScreensOnboardingCSS();
  injectScreensMainCSS();
  injectScreensSecondaryCSS();
  injectAppCSS();
  const root = ReactDOM.createRoot(document.getElementById("root"));
  root.render(<App />);
}

Object.assign(window, { App, Router, bootstrap, TWEAK_DEFAULTS });

// kick off
bootstrap();
