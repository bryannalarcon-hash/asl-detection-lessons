// screens-secondary.jsx — settings, info, error screens, designer notes

function SettingsLayout({ path, active, title, eyebrow, children }) {
  const items = [
    { to: "/settings/account", label: "Account" },
    { to: "/settings/app", label: "App preferences" },
    { to: "/settings/notifications", label: "Notifications" },
    { to: "/privacy", label: "Privacy & data" },
  ];
  return (
    <AppShell path={path}>
      <div className="page settings">
        <div className="settings-grid">
          <aside className="settings-side">
            <Eyebrow>Settings</Eyebrow>
            <nav className="settings-nav">
              {items.map(it => (
                <a key={it.to} href={`#${it.to}`} onClick={(e) => { e.preventDefault(); navigate(it.to); }}
                   className={active === it.to ? "active" : ""}>{it.label}</a>
              ))}
            </nav>
            <Rule />
            <p className="footnote">Settings sync to your account. Some preferences are also stored locally so they take effect before sign-in.</p>
          </aside>
          <section className="settings-body">
            <Eyebrow>{eyebrow}</Eyebrow>
            <h1 className="h-1" style={{ marginTop: 8, marginBottom: 24 }}>{title}</h1>
            {children}
          </section>
        </div>
      </div>
    </AppShell>
  );
}

function SettingsAccountScreen() {
  const [path] = useHashRoute();
  const [name, setName] = React.useState("Alex Rivera");
  const [email] = React.useState("alex@school.edu");
  const [saved, setSaved] = React.useState(false);
  return (
    <SettingsLayout path={path} active="/settings/account" eyebrow="Settings · 01" title="Account">
      <div className="settings-section card">
        <Eyebrow>Profile</Eyebrow>
        <div className="stack" style={{ gap: 16, marginTop: 16 }}>
          <Field label="Display name" htmlFor="dn"><Input id="dn" value={name} onChange={(e) => setName(e.target.value)} /></Field>
          <Field label="Email" htmlFor="em" hint="Change requires re-verification."><Input id="em" value={email} disabled /></Field>
          <div className="row" style={{ gap: 12, alignItems: "center" }}>
            <Button variant="primary" onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 1800); }}>Save changes</Button>
            {saved && <Badge variant="success">Saved</Badge>}
          </div>
        </div>
      </div>

      <div className="settings-section card">
        <Eyebrow>Password</Eyebrow>
        <div className="stack" style={{ gap: 16, marginTop: 16 }}>
          <Field label="Current password" htmlFor="cpw"><Input id="cpw" type="password" /></Field>
          <Field label="New password" htmlFor="npw" hint="Eight characters minimum, anything works after that."><Input id="npw" type="password" /></Field>
          <Button variant="secondary" style={{ alignSelf: "flex-start" }}>Update password</Button>
        </div>
      </div>

      <div className="settings-section card">
        <Eyebrow>Danger zone</Eyebrow>
        <div className="stack" style={{ gap: 14, marginTop: 14 }}>
          <p className="body-prose" style={{ fontSize: "0.95rem" }}>Delete your account and all practice history. This cannot be undone. Reference videos and instructor credits aren't affected — they belong to the demonstrators.</p>
          <Button variant="secondary" style={{ alignSelf: "flex-start", color: "var(--error)", borderColor: "var(--error)" }}>Delete account…</Button>
        </div>
      </div>
    </SettingsLayout>
  );
}

function SettingsAppScreen() {
  const [path] = useHashRoute();
  const [camDefault, setCamDefault] = React.useState(true);
  const [refDefault, setRefDefault] = React.useState(true);
  const [reduceMotion, setReduceMotion] = React.useState(false);
  const [mirror, setMirror] = React.useState(true);
  const [speed, setSpeed] = React.useState("1x");
  const [autoAdv, setAutoAdv] = React.useState("camera");
  return (
    <SettingsLayout path={path} active="/settings/app" eyebrow="Settings · 02" title="App preferences">
      <div className="settings-section card">
        <Eyebrow>Practice defaults</Eyebrow>
        <p className="footnote" style={{ marginTop: 6 }}>These prefill the Lesson Intro toggles. Stored locally in this browser.</p>
        <div className="stack" style={{ gap: 18, marginTop: 18 }}>
          <SettingRow label="Camera on for new lessons" hint="Switching off uses self-report mode by default.">
            <Toggle on={camDefault} onChange={setCamDefault} />
          </SettingRow>
          <SettingRow label="Reference video shown" hint="Hiding the reference tests recall.">
            <Toggle on={refDefault} onChange={setRefDefault} />
          </SettingRow>
          <SettingRow label="Mirror camera preview" hint="Flip the preview horizontally — many people find this more natural.">
            <Toggle on={mirror} onChange={setMirror} />
          </SettingRow>
          <SettingRow label="Reduce motion" hint="Removes non-essential transitions and pulses.">
            <Toggle on={reduceMotion} onChange={setReduceMotion} />
          </SettingRow>
        </div>
      </div>

      <div className="settings-section card">
        <Eyebrow>Playback</Eyebrow>
        <div className="stack" style={{ gap: 18, marginTop: 18 }}>
          <SettingRow label="Reference playback speed" hint="0.5× is recommended while you're learning a new sign.">
            <Segmented value={speed} options={["0.5x","0.75x","1x","1.25x"]} onChange={setSpeed} />
          </SettingRow>
          <SettingRow label="Auto-advance after pass" hint="When the camera detects a match, do we continue automatically?">
            <Segmented value={autoAdv} options={["off","camera","always"]} onChange={setAutoAdv} />
          </SettingRow>
        </div>
      </div>
    </SettingsLayout>
  );
}

function SettingRow({ label, hint, children }) {
  return (
    <div className="settings-row">
      <div className="settings-row-text">
        <div className="settings-row-label">{label}</div>
        {hint && <div className="footnote settings-row-hint">{hint}</div>}
      </div>
      <div className="settings-row-control">{children}</div>
    </div>
  );
}

function Segmented({ value, options, onChange }) {
  return (
    <div className="segmented">
      {options.map(o => (
        <button key={o} className={value === o ? "active" : ""} onClick={() => onChange(o)}>{o}</button>
      ))}
    </div>
  );
}

function SettingsNotificationsScreen() {
  const [path] = useHashRoute();
  const [streak, setStreak] = React.useState(true);
  const [weekly, setWeekly] = React.useState(true);
  const [marketing, setMarketing] = React.useState(false);
  const [hour, setHour] = React.useState("7pm");
  return (
    <SettingsLayout path={path} active="/settings/notifications" eyebrow="Settings · 03" title="Notification preferences">
      <div className="settings-section card">
        <Eyebrow>Email</Eyebrow>
        <div className="stack" style={{ gap: 18, marginTop: 18 }}>
          <SettingRow label="Daily streak reminder" hint="One nudge per day if you haven't practiced yet.">
            <Toggle on={streak} onChange={setStreak} />
          </SettingRow>
          <SettingRow label="Weekly progress digest" hint="Sundays at 9 AM local — what you practiced, what's due for review.">
            <Toggle on={weekly} onChange={setWeekly} />
          </SettingRow>
          <SettingRow label="Pilot updates" hint="Occasional notes about new lessons, features, and the demonstrators.">
            <Toggle on={marketing} onChange={setMarketing} />
          </SettingRow>
        </div>
      </div>
      <div className="settings-section card">
        <Eyebrow>Timing</Eyebrow>
        <div className="stack" style={{ gap: 18, marginTop: 18 }}>
          <SettingRow label="Streak reminder hour" hint="Pick a time you're usually free.">
            <Segmented value={hour} options={["9am","12pm","6pm","7pm","9pm"]} onChange={setHour} />
          </SettingRow>
        </div>
      </div>
      <p className="footnote">All emails come from <span className="mono" style={{ color: "var(--fg)" }}>hello@aslpilot.org</span>. Unsubscribe from any email or here.</p>
    </SettingsLayout>
  );
}

function PrivacyScreen() {
  const [path] = useHashRoute();
  return (
    <AppShell path={path}>
      <div className="page-narrow info">
        <Crumbs items={[{ label: "Dashboard", href: "/dashboard" }, { label: "Privacy & data" }]} />
        <Eyebrow>Privacy</Eyebrow>
        <h1 className="h-1">Privacy & data.</h1>
        <p className="lede">A pilot is the right time to be specific. Here's what ASL Pilot collects, what it doesn't, and what you can take with you.</p>

        <section className="info-section">
          <h2 className="h-3">The camera</h2>
          <p className="body-prose">The hand-tracking model runs on your device, in your browser, via WebAssembly. Frames are read, scored, and discarded in memory. We never write video or images to disk on our servers because none of them ever reach our servers.</p>
        </section>

        <section className="info-section">
          <h2 className="h-3">Practice telemetry</h2>
          <p className="body-prose">When you complete a rep, we store a small JSON record: lesson, sign, drill, timestamp, and a 0–1 pass score. This lets us draw your activity heatmap and schedule review. No biometric data is stored.</p>
        </section>

        <section className="info-section">
          <h2 className="h-3">Your data, exported</h2>
          <p className="body-prose">You can export everything we have about you as a JSON file from <a href="#/settings/account" onClick={(e) => { e.preventDefault(); navigate("/settings/account"); }} className="info-link">Account settings</a>. Deletion is final and immediate.</p>
        </section>

        <section className="info-section">
          <h2 className="h-3">Cookies</h2>
          <p className="body-prose">Two: a session cookie that keeps you signed in, and a settings cookie that remembers the toggles in App preferences. We do not use third-party analytics in the pilot.</p>
        </section>

        <Rule />
        <p className="footnote" style={{ marginTop: 16 }}>Questions? <a href="mailto:privacy@aslpilot.org" className="info-link">privacy@aslpilot.org</a>. Last updated <span className="mono">2026·02·14</span>.</p>
      </div>
    </AppShell>
  );
}

function HelpScreen() {
  const [path] = useHashRoute();
  const faqs = [
    { q: "Why does my camera feel choppy?", a: "Close other tabs using video. The hand-tracking model is fine on most laptops, but it competes with Zoom or YouTube for the GPU." },
    { q: "I'm left-handed. Is that a problem?", a: "No. The model is handedness-agnostic. Some demonstrators sign right-handed because they are; mirror your camera if it helps you parse the reference." },
    { q: "Why can't I get past a particular sign?", a: "Use the hint, slow the reference to 0.5×, and check your framing. If you're stuck, skip — the spaced-review system will bring the sign back later." },
    { q: "Is this enough to be fluent?", a: "No. ASL Pilot is a vocabulary tutor with a camera. Conversation, classifiers, register, and facial grammar all require a live teacher — ideally a Deaf one." },
    { q: "What's the relationship to Superbuilders?", a: "Superbuilders is a builder studio in Austin, Texas. ASL Pilot is one of its open pilots — small bets shipped publicly so we can learn in the open." },
  ];
  return (
    <AppShell path={path}>
      <div className="page-narrow info">
        <Crumbs items={[{ label: "Dashboard", href: "/dashboard" }, { label: "Help" }]} />
        <Eyebrow>Help</Eyebrow>
        <h1 className="h-1">How it works.</h1>
        <p className="lede">A short field guide to ASL Pilot.</p>

        <section className="info-section">
          <h2 className="h-3">The practice loop</h2>
          <p className="body-prose">Every sign is taught in three drills: handshape, movement, sign. You repeat each three times. The camera scores you on hand shape and motion match. The match score lights up green as you get close; if it auto-advances, the score crossed a threshold.</p>
          <p className="body-prose">If the camera misreads you, just click <span style={{ color: "var(--fg)" }}>Continue</span>. You're the final judge.</p>
        </section>

        <section className="info-section">
          <h2 className="h-3">Common questions</h2>
          <dl className="faq">
            {faqs.map((f, i) => (
              <details key={i} className="faq-item">
                <summary><span className="mono faq-num">№ {String(i + 1).padStart(2, "0")}</span><span>{f.q}</span></summary>
                <p className="body-prose">{f.a}</p>
              </details>
            ))}
          </dl>
        </section>

        <section className="info-section">
          <h2 className="h-3">Still stuck?</h2>
          <p className="body-prose">Email <a href="mailto:hello@aslpilot.org" className="info-link">hello@aslpilot.org</a>. We read everything. Reply usually arrives within a business day.</p>
        </section>
      </div>
    </AppShell>
  );
}

function AboutScreen() {
  const [path] = useHashRoute();
  return (
    <AppShell path={path}>
      <div className="page-narrow info">
        <Crumbs items={[{ label: "Dashboard", href: "/dashboard" }, { label: "About & credits" }]} />
        <Eyebrow>About</Eyebrow>
        <h1 className="h-1">About & credits.</h1>
        <p className="lede">ASL Pilot is an open pilot from Superbuilders in Austin, Texas. We're a small studio that ships small things — frequently, in public, with our names on them.</p>

        <section className="info-section">
          <h2 className="h-3">Demonstrators</h2>
          <p className="body-prose">All reference videos were filmed with Deaf instructors paid at fair professional rates. Without them, ASL Pilot is a webcam aimed at nothing.</p>
          <ul className="credits-list">
            <li><span className="credit-name">Maya R.</span> · ASL instructor, Texas School for the Deaf · Greetings, Numbers, Time</li>
            <li><span className="credit-name">Daniel V.</span> · ASL instructor, Austin Community College · Family, Feelings, Phrases</li>
            <li><span className="credit-name">Priya G.</span> · ASL coach · Verbs, Question words, Animals</li>
            <li><span className="credit-name">Jordan T.</span> · ASL educator · Food, Places, Colors</li>
          </ul>
        </section>

        <section className="info-section">
          <h2 className="h-3">Model</h2>
          <p className="body-prose">A small hand-pose model trained on our own footage of these demonstrators, plus a public hand-keypoint dataset. It runs in the browser via WebAssembly. It is intentionally narrow: it scores handshape and motion, nothing else.</p>
        </section>

        <section className="info-section">
          <h2 className="h-3">Team</h2>
          <p className="body-prose">Built by the Superbuilders studio in East Austin. Design and engineering by the in-house team; ASL pedagogy reviewed by the demonstrators above. We are not Deaf and do not speak for Deaf culture; we are learners trying to learn well.</p>
        </section>

        <section className="info-section">
          <h2 className="h-3">Colophon</h2>
          <p className="body-prose">Set in <em>Newsreader</em> and <em>IBM Plex</em>. Built in plain HTML, plain CSS, and just enough JavaScript. No third-party tracking. Hosted on Texas wind.</p>
        </section>
      </div>
    </AppShell>
  );
}

function CameraDeniedScreen() {
  const [path] = useHashRoute();
  return (
    <AppShell path={path}>
      <div className="page-narrow err">
        <div className="err-card card">
          <div className="err-icon">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <line x1="1" y1="1" x2="23" y2="23" />
              <path d="M21 21H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h3m3-3h6l2 3h4a2 2 0 0 1 2 2v9.34m-7.72-2.06a4 4 0 1 1-5.56-5.56" />
            </svg>
          </div>
          <Eyebrow>Camera blocked</Eyebrow>
          <h1 className="h-1" style={{ marginTop: 8 }}>We can't see you.</h1>
          <p className="lede">Your browser is blocking camera access for ASL Pilot. Click the camera icon in your address bar and choose <span style={{ color: "var(--fg)" }}>Allow</span>, then try again. Or continue in self-report mode — you'll judge your own signs.</p>
          <div className="row" style={{ gap: 12, marginTop: 24, flexWrap: "wrap" }}>
            <Button variant="primary" onClick={() => navigate("/onboarding/camera")}>I've re-enabled it</Button>
            <Button variant="secondary" onClick={() => navigate("/dashboard")}>Continue without camera</Button>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function OfflineScreen() {
  const [path] = useHashRoute();
  return (
    <AppShell path={path}>
      <div className="page-narrow err">
        <div className="err-card card">
          <div className="err-icon">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <line x1="1" y1="1" x2="23" y2="23" />
              <path d="M16.72 11.06A10.94 10.94 0 0 1 19 12.55M5 12.55a10.94 10.94 0 0 1 5.17-2.39M10.71 5.05A16 16 0 0 1 22.58 9M1.42 9a15.91 15.91 0 0 1 4.7-2.88M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01" />
            </svg>
          </div>
          <Eyebrow>Offline</Eyebrow>
          <h1 className="h-1" style={{ marginTop: 8 }}>The network looks down.</h1>
          <p className="lede">ASL Pilot needs the internet to load lessons and reference videos. Practice you've started will resume where you left off when you're back online.</p>
          <div className="err-tips">
            <span><span className="mono err-tip-num">01</span> Check your wifi or cellular signal</span>
            <span><span className="mono err-tip-num">02</span> If you're on a school network, your firewall may block video</span>
            <span><span className="mono err-tip-num">03</span> Try the dashboard — recent lessons are cached</span>
          </div>
          <div className="row" style={{ gap: 12, marginTop: 24, flexWrap: "wrap" }}>
            <Button variant="primary" onClick={() => window.location.reload()}>Try again</Button>
            <Button variant="secondary" onClick={() => navigate("/dashboard")}>Go to dashboard</Button>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function NotFoundScreen() {
  return (
    <div className="notfound-shell">
      <PublicNav />
      <main className="notfound-main">
        <div className="page-narrow err">
          <div className="err-card notfound-card">
            <Eyebrow accent>404</Eyebrow>
            <h1 className="h-1" style={{ marginTop: 8, fontSize: "clamp(2.6rem, 6vw, 4.4rem)" }}>We couldn't find that page.</h1>
            <p className="lede">It may have moved, or the lesson slug may be wrong. Two ways back in:</p>
            <div className="row" style={{ gap: 12, marginTop: 24, flexWrap: "wrap" }}>
              <Button variant="primary" onClick={() => navigate("/dashboard")}>Back to dashboard</Button>
              <Button variant="secondary" onClick={() => navigate("/lessons")}>Browse lessons</Button>
            </div>
            <Rule />
            <p className="footnote" style={{ marginTop: 16 }}>If this keeps happening, drop us a line at <a href="mailto:hello@aslpilot.org" className="info-link">hello@aslpilot.org</a> — we'll fix the link.</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function DesignerNotesScreen() {
  return (
    <div className="notes-shell">
      <PublicNav />
      <div className="page-narrow notes">
        <Eyebrow accent>Designer notes</Eyebrow>
        <h1 className="h-1">Eval & alternatives.</h1>
        <p className="lede">A short critique of the current ASL Pilot, and the rationale behind the three directions you can switch between in this prototype.</p>

        <section className="info-section">
          <h2 className="h-3">What's working in the current site</h2>
          <ul className="notes-list">
            <li><span className="mono notes-num">✓</span> Plain-spoken copy: "Practice ASL with your camera" is honest about the scope.</li>
            <li><span className="mono notes-num">✓</span> Three-drill practice loop (handshape · movement · sign · ×3 reps) is pedagogically sound.</li>
            <li><span className="mono notes-num">✓</span> Privacy stance ("video stays on your device") is well-placed near the hero.</li>
            <li><span className="mono notes-num">✓</span> Activity heatmap on the dashboard is a clear motivator.</li>
            <li><span className="mono notes-num">✓</span> The disclaimer "not full ASL — practice with a Deaf instructor" is the right intellectual honesty.</li>
          </ul>
        </section>

        <section className="info-section">
          <h2 className="h-3">What's not</h2>
          <ol className="notes-numbered">
            <li><b>It reads as an internal dev build.</b> Dev-mode buttons (Force allow, Force deny, Skip login, Mark verified, Mock CV) leak into the live UI. "Backend not reachable" appears as user-facing copy. <span className="mono" style={{ color: "var(--accent)" }}>ux-spec.md §15</span>-style placeholders are visible to learners.</li>
            <li><b>The display font is doing too much.</b> The pixelated/condensed display face is striking, but it fights legibility at body sizes and at small caps; it telegraphs "indie dev tool," not "course of study."</li>
            <li><b>The dark mode is the only mode.</b> For a self-study tool an undergrad will use during the day, this is a tax. Editorial reading wants warm paper, not black.</li>
            <li><b>The reference is Nyan Cat.</b> A placeholder, sure — but ASL is a Deaf cultural language. The reference slot is the most important affordance on the page and deserves a real person from the very first mock.</li>
            <li><b>Onboarding hides the camera.</b> Step 1 talks about hands; step 2 asks for camera permission with no preview; the camera box only appears on step 3 (calibration), where it shows "Camera not available." The user has accepted a permission they haven't yet seen the value of.</li>
            <li><b>The catalog is a flat grid of 12 identical cards.</b> There's no sense of order, difficulty, time investment, or what the user has touched. Information density is too low.</li>
            <li><b>Practice screen wastes the most expensive screen real estate.</b> The mirrored "your camera" view is a small green panel; the (Nyan Cat) reference is much larger. The two should be roughly equal, and the rest of the page is empty.</li>
            <li><b>The voice is inconsistent.</b> "Practice ASL with your camera" (warm, direct) sits next to "Placeholder. See ux-spec.md §4 Forgot password for the full feature spec" (raw build artifact). Pick one.</li>
            <li><b>Brand <em>name</em> is good. Brand <em>system</em> is missing.</b> "ASL Pilot · A Superbuilders Foundry project" is great positioning. There's no typography ladder, no color theory beyond "indigo on near-black," no editorial layout system to scale into 75 lessons.</li>
            <li><b>Mobile is not addressed.</b> Layouts assume desktop; the existing onboarding screens leak white space on small viewports.</li>
          </ol>
        </section>

        <section className="info-section">
          <h2 className="h-3">The brief I'm designing against</h2>
          <p className="body-prose">An undergraduate, self-studying, in a coffee shop or dorm. Wants something that <em>feels like a course of study</em>, not a tech demo. Respects ASL as a real cultural language; doesn't pretend to teach fluency. Made in Austin by people who care.</p>
          <p className="body-prose">Tone: <span style={{ color: "var(--fg)" }}>editorial / academic</span> — closer to a New Yorker how-to or a university press field guide than a SaaS dashboard.</p>
        </section>

        <section className="info-section">
          <h2 className="h-3">The three directions</h2>
          <div className="notes-dirs">
            <article>
              <Eyebrow accent>A · Reader</Eyebrow>
              <h3 className="h-4" style={{ marginTop: 6 }}>Classical academic press.</h3>
              <p className="body-prose">Newsreader serif throughout. Warm cream paper. Terracotta accent. Numbered sections, sidenotes, justified margins where it earns its keep. Reads like the Texas State Historical Society reprint of a field guide. Best for: positioning ASL Pilot as serious, considered, not a toy.</p>
            </article>
            <article>
              <Eyebrow accent>B · Field Manual</Eyebrow>
              <h3 className="h-4" style={{ marginTop: 6 }}>Tufte / lab notebook.</h3>
              <p className="body-prose">IBM Plex Serif + Sans + Mono. Dot-grid paper background. Construction-orange accent. Square corners. Offset shadows on primary actions. Reads like an engineer's field journal: technical, annotated, no decoration without function. Best for: leaning into Superbuilders' "studio of builders" identity.</p>
            </article>
            <article>
              <Eyebrow accent>C · Studio</Eyebrow>
              <h3 className="h-4" style={{ marginTop: 6 }}>Contemporary editorial.</h3>
              <p className="body-prose">Instrument Serif italic display + clean sans body. Forest-green accent. Generous rounded radii. Asymmetric layouts, big confident type. Reads like a small press monograph or an Are.na essay. Best for: most "designed," most likely to stand out in the LMS-link tab of a college student.</p>
            </article>
          </div>
          <p className="footnote" style={{ marginTop: 18 }}>Use the <span className="mono" style={{ color: "var(--accent)" }}>Tweaks</span> button (bottom-right) to switch between A, B, and C across every screen. The screen-index list there lets you jump to any of the 23 screens.</p>
        </section>

        <section className="info-section">
          <h2 className="h-3">What I changed across the board</h2>
          <ul className="notes-list">
            <li><span className="mono notes-num">→</span> Removed every <code>[Dev:]</code> button, placeholder copy, and "see ux-spec.md §X" from the live UI.</li>
            <li><span className="mono notes-num">→</span> Replaced Nyan Cat with credited reference cards (Maya R., Daniel V., Priya G., Jordan T.) and an explicit "About the demonstrators" section in lesson intros.</li>
            <li><span className="mono notes-num">→</span> Made the camera the hero of the practice screen — equal weight to the reference, prominent overlays, real progress affordances.</li>
            <li><span className="mono notes-num">→</span> Catalog gets density: a list with sign chips, signal of progress, and search/filter; not 12 identical cards.</li>
            <li><span className="mono notes-num">→</span> Verify-email is interactive (six-digit code) rather than a placeholder page.</li>
            <li><span className="mono notes-num">→</span> Privacy / Help / About are written as real pages, not deferred to a spec doc.</li>
            <li><span className="mono notes-num">→</span> Responsive across mobile and desktop on every screen.</li>
            <li><span className="mono notes-num">→</span> Footer credit: <em>"A Superbuilders project · Made in Austin, TX"</em> grounds the brand.</li>
          </ul>
        </section>

        <Rule />
        <div className="row" style={{ justifyContent: "space-between", flexWrap: "wrap", gap: 16, marginTop: 24 }}>
          <Button variant="primary" onClick={() => navigate("/")}>Open the prototype →</Button>
          <Button variant="ghost" onClick={() => navigate("/dashboard")}>Skip to dashboard</Button>
        </div>
      </div>
      <Footer />
    </div>
  );
}

const SCREENS_SECONDARY_CSS = `
/* Settings */
.settings{padding-top:32px}
.settings-grid{display:grid;grid-template-columns:240px 1fr;gap:48px;align-items:start}
@media (max-width:760px){.settings-grid{grid-template-columns:1fr;gap:24px}}
.settings-side{position:sticky;top:96px;display:flex;flex-direction:column;gap:16px}
@media (max-width:760px){.settings-side{position:static}}
.settings-nav{display:flex;flex-direction:column}
.settings-nav a{padding:10px 0;color:var(--fg-muted);font-family:var(--font-ui);font-size:0.94rem;border-bottom:1px solid var(--line-soft);transition:color .15s}
.settings-nav a:last-child{border-bottom:0}
.settings-nav a:hover{color:var(--fg)}
.settings-nav a.active{color:var(--accent)}
:root[data-direction="reader"] .settings-nav a.active{box-shadow:inset 3px 0 0 var(--accent);padding-left:10px}
.settings-section{margin-bottom:24px}
.settings-row{display:grid;grid-template-columns:1fr auto;gap:24px;align-items:start;padding:14px 0;border-bottom:1px solid var(--line-soft)}
.settings-row:last-child{border-bottom:0}
@media (max-width:520px){.settings-row{grid-template-columns:1fr;gap:10px}}
.settings-row-text{display:flex;flex-direction:column;gap:4px}
.settings-row-label{font-family:var(--font-ui);font-size:0.96rem;font-weight:500}
.settings-row-hint{max-width:48ch}
.segmented{display:inline-flex;border:1px solid var(--line);border-radius:var(--radius-pill);overflow:hidden;background:var(--bg-paper)}
:root[data-direction="field"] .segmented{border-radius:0}
.segmented button{padding:6px 12px;font-family:var(--font-mono);font-size:0.78rem;color:var(--fg-muted);background:transparent;border:0;border-right:1px solid var(--line-soft);cursor:pointer}
.segmented button:last-child{border-right:0}
.segmented button:hover{color:var(--fg)}
.segmented button.active{background:var(--fg);color:var(--bg-paper)}
:root[data-direction="reader"] .segmented button.active{background:var(--accent)}

/* Info pages */
.info{padding-top:32px;padding-bottom:48px}
.info-section{margin-top:32px}
.info-section h2{margin-bottom:10px}
.info-link{color:var(--accent);text-decoration:underline;text-underline-offset:3px}
.credits-list{list-style:none;padding:0;margin:14px 0 0;display:flex;flex-direction:column;gap:0}
.credits-list li{padding:10px 0;border-bottom:1px solid var(--line-soft);font-family:var(--font-ui);font-size:0.94rem;color:var(--fg-muted)}
.credit-name{color:var(--fg);font-weight:500}

.faq{margin-top:14px;display:flex;flex-direction:column;gap:0}
.faq-item{padding:14px 0;border-top:1px solid var(--line-soft)}
.faq-item:last-child{border-bottom:1px solid var(--line-soft)}
.faq-item summary{display:flex;gap:14px;align-items:baseline;cursor:pointer;font-family:var(--font-display);font-size:1.05rem;list-style:none}
.faq-item summary::-webkit-details-marker{display:none}
.faq-item summary::after{content:"+";margin-left:auto;font-family:var(--font-mono);color:var(--fg-faint)}
.faq-item[open] summary::after{content:"−"}
.faq-num{color:var(--accent);font-size:0.78rem;min-width:36px}
.faq-item p{margin:10px 0 0 50px;font-size:0.96rem}
@media (max-width:520px){.faq-item p{margin-left:0}}

/* Error pages */
.err{padding-top:48px;padding-bottom:48px;display:flex;align-items:center;justify-content:center;min-height:60vh}
.err-card{max-width:560px;padding:32px}
.err-icon{width:48px;height:48px;display:flex;align-items:center;justify-content:center;color:var(--warn);margin-bottom:18px}
.err-tips{display:flex;flex-direction:column;gap:8px;margin-top:20px;font-family:var(--font-ui);font-size:0.92rem;color:var(--fg-muted)}
.err-tip-num{color:var(--accent);min-width:30px;display:inline-block;font-size:0.78rem}
.notfound-shell{min-height:100vh;display:flex;flex-direction:column}
.notfound-main{flex:1;display:flex;align-items:center;justify-content:center;padding:32px 0}
.notfound-card{background:transparent;border:0;box-shadow:none;padding:0;text-align:center}
.notfound-card .row{justify-content:center}

/* Notes */
.notes-shell{min-height:100vh;display:flex;flex-direction:column}
.notes{padding:48px 24px 80px;flex:1}
.notes-list{list-style:none;padding:0;margin:14px 0 0;display:flex;flex-direction:column;gap:10px}
.notes-list li{display:flex;gap:14px;align-items:baseline;font-family:var(--font-body);font-size:1rem;line-height:1.55;color:var(--fg)}
.notes-num{color:var(--success);font-size:0.82rem;min-width:24px;flex-shrink:0}
.notes-numbered{padding-left:0;margin:14px 0 0;list-style:none;counter-reset:n;display:flex;flex-direction:column;gap:20px}
.notes-numbered li{counter-increment:n;padding-left:48px;position:relative;font-family:var(--font-body);font-size:1rem;line-height:1.55}
.notes-numbered li::before{content:counter(n,decimal-leading-zero);position:absolute;left:0;top:0;font-family:var(--font-mono);font-size:0.84rem;color:var(--accent);letter-spacing:0.04em}
.notes-dirs{display:grid;grid-template-columns:1fr;gap:24px;margin-top:18px}
.notes-dirs article{padding:20px;background:var(--bg-paper);border:1px solid var(--line-soft);border-radius:var(--radius-md)}
:root[data-direction="field"] .notes-dirs article{border-radius:0}
.notes code{font-family:var(--font-mono);font-size:0.84rem;color:var(--accent);background:var(--accent-bg);padding:2px 6px;border-radius:3px}
:root[data-direction="field"] .notes code{border-radius:0}
`;

function injectScreensSecondaryCSS() {
  if (document.getElementById("__screens_sec_css")) return;
  const s = document.createElement("style");
  s.id = "__screens_sec_css";
  s.textContent = SCREENS_SECONDARY_CSS;
  document.head.appendChild(s);
}

Object.assign(window, {
  SettingsAccountScreen, SettingsAppScreen, SettingsNotificationsScreen,
  PrivacyScreen, HelpScreen, AboutScreen,
  CameraDeniedScreen, OfflineScreen, NotFoundScreen,
  DesignerNotesScreen,
  injectScreensSecondaryCSS,
});
