// screens-onboarding.jsx — 4-step onboarding flow

function OnboardingShell({ step, title, eyebrow, children, footer }) {
  return (
    <div className="onb-shell">
      <header className="onb-header">
        <a href="#/" onClick={(e) => { e.preventDefault(); navigate("/"); }}><Brand /></a>
        <OnbProgress step={step} />
        <button className="btn btn-ghost btn-sm" onClick={() => navigate("/dashboard")}>Skip onboarding</button>
      </header>
      <main className="onb-main page">
        <div className="onb-grid">
          <div className="onb-prose">
            <Eyebrow accent>{eyebrow || `Step ${step} of 4`}</Eyebrow>
            <h1 className="h-1" style={{ marginTop: 14 }}>{title}</h1>
            {children}
          </div>
          <aside className="onb-aside">{footer}</aside>
        </div>
      </main>
    </div>
  );
}

function OnbProgress({ step }) {
  const labels = ["Welcome", "Camera", "Calibration", "First sign"];
  return (
    <div className="onb-progress">
      {labels.map((l, i) => {
        const n = i + 1;
        const state = n < step ? "done" : n === step ? "active" : "pending";
        return (
          <React.Fragment key={l}>
            <div className={`onb-step-pill ${state}`}>
              <span className="onb-step-num mono">{String(n).padStart(2, "0")}</span>
              <span className="onb-step-label">{l}</span>
            </div>
            {i < labels.length - 1 && <span className="onb-step-rule" />}
          </React.Fragment>
        );
      })}
    </div>
  );
}

function WelcomeStep() {
  return (
    <OnboardingShell
      step={1}
      eyebrow="Onboarding · 01 of 04"
      title={<>You're about to learn <em style={{ fontStyle: "italic" }}>seventy-five</em> essential ASL signs.</>}
      footer={
        <div className="card">
          <Eyebrow>What to expect</Eyebrow>
          <ul className="onb-list">
            <li><span className="mono onb-list-num">3 min</span><span>Camera permission & framing</span></li>
            <li><span className="mono onb-list-num">~5 min</span><span>Your first guided sign</span></li>
            <li><span className="mono onb-list-num">~10 min</span><span>A typical lesson, going forward</span></li>
          </ul>
        </div>
      }
    >
      <ul className="onb-bullets">
        <li>
          <Eyebrow>§ Method</Eyebrow>
          <p className="body-prose">We check the shape and movement of your hands. We don't grade facial grammar — that takes a real instructor.</p>
        </li>
        <li>
          <Eyebrow>§ Privacy</Eyebrow>
          <p className="body-prose">Your video never leaves the device. The model runs locally in the browser; nothing is uploaded.</p>
        </li>
        <li>
          <Eyebrow>§ Limits</Eyebrow>
          <p className="body-prose">For full ASL fluency — conversation, classifiers, register — find a Deaf instructor. This is a flashcard tutor with a camera.</p>
        </li>
      </ul>
      <div className="row" style={{ gap: 12, marginTop: 32, flexWrap: "wrap" }}>
        <Button variant="primary" size="lg" onClick={() => navigate("/onboarding/camera")}>Set up the camera →</Button>
        <Button variant="ghost" onClick={() => navigate("/dashboard")}>Skip for now</Button>
      </div>
    </OnboardingShell>
  );
}

function CameraStep() {
  const [state, setState] = React.useState("idle"); // idle | granted | denied
  return (
    <OnboardingShell
      step={2}
      eyebrow="Onboarding · 02 of 04"
      title="Permit the camera."
      footer={
        <div className="card">
          <Eyebrow>Compatibility</Eyebrow>
          <ul className="onb-list">
            <li><span className="mono onb-list-num">✓</span><span>Chrome 109+, Safari 16+, Firefox 110+</span></li>
            <li><span className="mono onb-list-num">✓</span><span>Built-in or USB webcam, 720p or higher</span></li>
            <li><span className="mono onb-list-num">·</span><span>Tablet supported; phone is fine for browsing only</span></li>
          </ul>
          <Rule />
          <p className="footnote" style={{ marginTop: 12 }}>
            Browsers will show a permission prompt; choose <span style={{ color: "var(--fg)" }}>Allow</span>. You can change this later in settings.
          </p>
        </div>
      }
    >
      <p className="lede" style={{ marginTop: 16 }}>
        We need your camera so the practice loop can read the shape and motion of your hands against the reference. Your video stays on this device.
      </p>
      <div className="onb-cam-stack">
        {state !== "denied" && (
          <Button variant="primary" size="lg" onClick={() => setState("granted")}>
            <CameraIcon /> Turn on the camera
          </Button>
        )}
        {state === "granted" && (
          <div className="onb-cam-ok">
            <Badge variant="success">Camera permitted</Badge>
            <Button variant="primary" onClick={() => navigate("/onboarding/calibrate")}>Continue to calibration →</Button>
          </div>
        )}
        {state === "denied" && (
          <div className="onb-cam-denied">
            <Badge variant="warn">Permission denied</Badge>
            <p className="body-prose" style={{ fontSize: "0.96rem" }}>Click the camera icon in your browser's address bar, choose <span style={{ color: "var(--fg)" }}>Allow</span>, then try again.</p>
            <div className="row" style={{ gap: 12 }}>
              <Button variant="primary" onClick={() => setState("idle")}>I've re-enabled it</Button>
              <Button variant="ghost" onClick={() => navigate("/onboarding/calibrate")}>Continue without camera</Button>
            </div>
          </div>
        )}
        <button className="onb-cam-deny-link" onClick={() => setState("denied")}>
          Simulate "permission denied"
        </button>
      </div>
    </OnboardingShell>
  );
}

function CameraIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
      <circle cx="12" cy="13" r="4" />
    </svg>
  );
}

function CalibrationStep() {
  const [mirror, setMirror] = React.useState(true);
  const [framingOk, setFramingOk] = React.useState(false);
  return (
    <OnboardingShell
      step={3}
      eyebrow="Onboarding · 03 of 04"
      title="Frame yourself."
      footer={
        <div className="card">
          <Eyebrow>Calibration checklist</Eyebrow>
          <ul className="onb-list">
            <li><span className="mono onb-list-num">A</span><span>Head and shoulders visible in the box</span></li>
            <li><span className="mono onb-list-num">B</span><span>Both hands fit when raised in front of you</span></li>
            <li><span className="mono onb-list-num">C</span><span>Light comes from the front, not behind</span></li>
            <li><span className="mono onb-list-num">D</span><span>Plain wall behind you, if you can</span></li>
          </ul>
        </div>
      }
    >
      <p className="lede" style={{ marginTop: 16 }}>
        Move closer or further until your head, shoulders, and both hands fit comfortably inside the framing guide. Toggle the mirror if it feels unnatural reversed.
      </p>
      <div className="onb-cal-stage">
        <div className="onb-cal-frame">
          <span className="onb-cal-corner tl" />
          <span className="onb-cal-corner tr" />
          <span className="onb-cal-corner bl" />
          <span className="onb-cal-corner br" />
          <div className="onb-cal-figure">
            <MediaPlaceholder label="Live camera · mirrored" aspect="16/10" />
          </div>
          <div className="onb-cal-readout">
            <span className="eyebrow">Frame</span>
            <span className="mono" style={{ color: "var(--success)" }}>{framingOk ? "✓ ok" : "adjusting…"}</span>
          </div>
        </div>
        <div className="onb-cal-controls">
          <Toggle on={mirror} onChange={setMirror} label="Mirror preview" />
          <Toggle on={framingOk} onChange={setFramingOk} label="Confirm framing" />
          <Rule />
          <Button variant="primary" disabled={!framingOk} onClick={() => navigate("/onboarding/first-sign")}>Looks good — continue →</Button>
          <Button variant="ghost" size="sm" onClick={() => navigate("/onboarding/camera")}>← Back to camera setup</Button>
        </div>
      </div>
    </OnboardingShell>
  );
}

function FirstSignStep() {
  const [drill, setDrill] = React.useState(0); // 0 handshape, 1 movement, 2 sign, 3 done
  const labels = ["Handshape", "Movement", "Whole sign"];
  const next = () => {
    if (drill >= 2) navigate("/dashboard");
    else setDrill(d => d + 1);
  };
  return (
    <OnboardingShell
      step={4}
      eyebrow="Onboarding · 04 of 04 · Your first sign"
      title="HELLO."
      footer={
        <div className="card">
          <Eyebrow>About this sign</Eyebrow>
          <p className="body-prose" style={{ fontSize: "0.94rem", marginTop: 8 }}>
            A flat hand at the temple, swung forward and out like a salute. It's a general greeting — appropriate from a casual hi to a formal hello.
          </p>
          <Rule />
          <Eyebrow>Demonstrator</Eyebrow>
          <p className="footnote" style={{ marginTop: 8 }}>
            <span className="mono" style={{ color: "var(--fg)" }}>Maya R.</span> · ASL instructor, Texas School for the Deaf
          </p>
        </div>
      }
    >
      <div className="onb-fs">
        <div className="onb-fs-stages">
          {labels.map((l, i) => (
            <div key={l} className={`onb-fs-stage ${i < drill ? "done" : i === drill ? "active" : ""}`}>
              <span className="mono onb-fs-num">{String(i + 1).padStart(2, "0")}</span>
              <span>{l}</span>
            </div>
          ))}
        </div>
        <div className="onb-fs-grid">
          <figure className="onb-fs-cell">
            <figcaption className="onb-fs-cap"><Eyebrow>You</Eyebrow></figcaption>
            <MediaPlaceholder label="Your camera · live" aspect="4/3" />
          </figure>
          <figure className="onb-fs-cell">
            <figcaption className="onb-fs-cap"><Eyebrow>Reference</Eyebrow></figcaption>
            <MediaPlaceholder label="Maya R. · HELLO · slow" aspect="4/3" />
          </figure>
        </div>
        <div className="onb-fs-controls">
          <Button variant="secondary" size="sm" onClick={() => setDrill(Math.max(0, drill - 1))}>← Back a drill</Button>
          <span className="help">Tap continue when your hand matches the reference — or wait for the camera to detect a match.</span>
          <Button variant="primary" onClick={next}>{drill >= 2 ? "Finish onboarding →" : "Continue"}</Button>
        </div>
      </div>
    </OnboardingShell>
  );
}

const ONB_CSS = `
.onb-shell{min-height:100vh;display:flex;flex-direction:column}
.onb-header{display:flex;align-items:center;justify-content:space-between;padding:18px 24px;border-bottom:1px solid var(--line-soft);gap:24px;flex-wrap:wrap}
:root[data-direction="reader"] .onb-header{border-bottom-style:double;border-bottom-width:3px}
.onb-progress{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.onb-step-pill{display:flex;align-items:center;gap:8px;padding:6px 12px;border:1px solid var(--line);border-radius:var(--radius-pill);color:var(--fg-subtle);font-family:var(--font-ui);font-size:0.85rem}
:root[data-direction="field"] .onb-step-pill{border-radius:0}
.onb-step-pill.active{border-color:var(--accent);color:var(--accent);background:var(--accent-bg)}
.onb-step-pill.done{border-color:var(--line);color:var(--fg)}
.onb-step-num{font-size:0.74rem;color:var(--fg-faint)}
.onb-step-pill.active .onb-step-num{color:var(--accent)}
.onb-step-rule{flex:1;min-width:8px;max-width:24px;height:1px;background:var(--line)}
@media (max-width:760px){.onb-step-rule{display:none}.onb-step-label{display:none}}

.onb-main{flex:1;padding:48px 0 64px}
.onb-grid{display:grid;grid-template-columns:1.4fr 1fr;gap:48px;align-items:start}
@media (max-width:880px){.onb-grid{grid-template-columns:1fr;gap:32px}}

.onb-bullets{list-style:none;padding:0;margin:32px 0 0;display:flex;flex-direction:column;gap:20px}
.onb-bullets li{padding-top:16px;border-top:1px solid var(--line-soft)}
.onb-bullets li:first-child{border-top:0;padding-top:0}
.onb-bullets p{margin:6px 0 0}

.onb-list{list-style:none;padding:0;margin:12px 0 0;display:flex;flex-direction:column;gap:0;font-family:var(--font-ui);font-size:0.92rem}
.onb-list li{display:flex;gap:14px;align-items:baseline;padding:10px 0;border-top:1px solid var(--line-soft);color:var(--fg-muted)}
.onb-list li:first-child{border-top:0}
.onb-list-num{color:var(--accent);min-width:54px;font-size:0.82rem}

.onb-cam-stack{display:flex;flex-direction:column;gap:24px;margin-top:32px;align-items:flex-start}
.onb-cam-ok,.onb-cam-denied{display:flex;flex-direction:column;gap:16px;align-items:flex-start}
.onb-cam-deny-link{font-family:var(--font-mono);font-size:0.74rem;color:var(--fg-faint);text-decoration:underline;text-underline-offset:3px;cursor:pointer;background:none;border:0;padding:0}
.onb-cam-deny-link:hover{color:var(--accent)}

.onb-cal-stage{margin-top:32px;display:grid;grid-template-columns:1.6fr 1fr;gap:24px;align-items:start}
@media (max-width:760px){.onb-cal-stage{grid-template-columns:1fr}}
.onb-cal-frame{position:relative;padding:16px;border:1px dashed var(--line)}
:root[data-direction="field"] .onb-cal-frame{border-style:solid}
:root[data-direction="reader"] .onb-cal-frame{border-style:solid;border-width:1px;background:var(--bg-paper)}
:root[data-direction="studio"] .onb-cal-frame{border-radius:18px}
.onb-cal-corner{position:absolute;width:18px;height:18px;border:1.5px solid var(--accent)}
.onb-cal-corner.tl{top:-1px;left:-1px;border-right:0;border-bottom:0}
.onb-cal-corner.tr{top:-1px;right:-1px;border-left:0;border-bottom:0}
.onb-cal-corner.bl{bottom:-1px;left:-1px;border-right:0;border-top:0}
.onb-cal-corner.br{bottom:-1px;right:-1px;border-left:0;border-top:0}
.onb-cal-figure .media-ph{aspect-ratio:16/10}
.onb-cal-readout{display:flex;justify-content:space-between;align-items:baseline;margin-top:10px;font-family:var(--font-mono);font-size:0.78rem;color:var(--fg-muted)}
.onb-cal-controls{display:flex;flex-direction:column;gap:16px}

.onb-fs{margin-top:24px;display:flex;flex-direction:column;gap:24px}
.onb-fs-stages{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
@media (max-width:600px){.onb-fs-stages{grid-template-columns:1fr}}
.onb-fs-stage{display:flex;align-items:center;gap:12px;padding:12px 14px;border:1px solid var(--line-soft);font-family:var(--font-ui);font-size:0.92rem;color:var(--fg-muted);border-radius:var(--radius-md)}
:root[data-direction="field"] .onb-fs-stage{border-radius:0}
.onb-fs-stage.active{border-color:var(--accent);color:var(--accent);background:var(--accent-bg)}
.onb-fs-stage.done{color:var(--fg);border-color:var(--line)}
.onb-fs-stage.done .onb-fs-num{color:var(--success)}
.onb-fs-num{color:var(--fg-faint);font-size:0.78rem}
.onb-fs-stage.active .onb-fs-num{color:var(--accent)}
.onb-fs-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}
@media (max-width:600px){.onb-fs-grid{grid-template-columns:1fr}}
.onb-fs-cell{margin:0;display:flex;flex-direction:column;gap:8px}
.onb-fs-cap{display:flex;justify-content:space-between;align-items:baseline}
.onb-fs-controls{display:flex;justify-content:space-between;align-items:center;gap:16px;padding-top:16px;border-top:1px solid var(--line-soft);flex-wrap:wrap}
.onb-fs-controls .help{flex:1;min-width:0}
`;

function injectScreensOnboardingCSS() {
  if (document.getElementById("__screens_onb_css")) return;
  const s = document.createElement("style");
  s.id = "__screens_onb_css";
  s.textContent = ONB_CSS;
  document.head.appendChild(s);
}

Object.assign(window, {
  WelcomeStep, CameraStep, CalibrationStep, FirstSignStep,
  injectScreensOnboardingCSS,
});
