// screens-public.jsx — landing + auth screens (signin/signup/forgot/verify)

function LandingScreen() {
  return (
    <MarketingShell>
      <section className="landing-hero">
        <div className="page">
          <div className="landing-grid">
            <div className="landing-lede">
              <EyebrowLine>Vol. 01 · ASL Pilot · A self-study reader</EyebrowLine>
              <h1 className="h-1 landing-title">
                A patient first course in <em className="landing-em">American Sign Language</em>, taught one sign at a time.
              </h1>
              <p className="lede">
                Seventy-five foundational signs. A camera-aware practice loop. Reference video from Deaf instructors. Self-paced, private, and yours to repeat as often as it takes.
              </p>
              <div className="landing-cta">
                <Button variant="primary" size="lg" onClick={() => navigate("/signup")}>Create your account</Button>
                <Button variant="secondary" size="lg" onClick={() => navigate("/signin")}>I already have one</Button>
              </div>
              <p className="footnote">
                <span className="mono" style={{ color: "var(--accent)" }}>¹</span> This is vocabulary practice, not full ASL. For grammar, conversation, and fluency, study with a Deaf instructor.
              </p>
            </div>
            <aside className="landing-aside">
              <figure className="landing-card">
                <MediaPlaceholder label="Reference · HELLO" aspect="3/4" />
                <figcaption className="landing-cap">
                  <Eyebrow>Plate 01</Eyebrow>
                  <div className="h-3" style={{ marginTop: 6 }}>HELLO</div>
                  <p className="caption-body">A flat hand at the brow, swung forward and away. Begin every conversation here.</p>
                </figcaption>
              </figure>
              <ul className="landing-meta">
                <li><span className="mono">75</span> signs in the pilot syllabus</li>
                <li><span className="mono">12</span> themed lessons</li>
                <li><span className="mono">0</span> video uploaded to our servers</li>
              </ul>
            </aside>
          </div>
        </div>
      </section>

      <section className="page" style={{ paddingTop: 64, paddingBottom: 64 }}>
        <Rule variant="strong" />
        <div className="landing-three" style={{ marginTop: 32 }}>
          <article>
            <Eyebrow>§ 01 · Method</Eyebrow>
            <h3 className="h-3" style={{ marginTop: 8 }}>Three drills per sign</h3>
            <p className="body-prose">Each sign is taught in three small drills: handshape, then movement, then the whole sign. You repeat each three times. Brief failure is encouraged.</p>
          </article>
          <article>
            <Eyebrow>§ 02 · Privacy</Eyebrow>
            <h3 className="h-3" style={{ marginTop: 8 }}>Your camera, your device</h3>
            <p className="body-prose">The camera reads your hands on-device. No frames are uploaded. The model runs in your browser; you can practice on the train.</p>
          </article>
          <article>
            <Eyebrow>§ 03 · Limits</Eyebrow>
            <h3 className="h-3" style={{ marginTop: 8 }}>What this is not</h3>
            <p className="body-prose">ASL Pilot does not grade facial grammar, classifiers, or fingerspelling speed. Treat it as a vocabulary tutor — a flashcard deck with a camera.</p>
          </article>
        </div>
      </section>

      <section className="landing-credit page">
        <Rule />
        <div className="landing-credit-row">
          <div>
            <Eyebrow>Editorial note</Eyebrow>
            <p className="body-prose" style={{ marginTop: 8, maxWidth: "48ch" }}>
              Sign demonstrations were filmed with Deaf instructors at <span style={{ fontStyle: "italic" }}>Texas School for the Deaf</span> in Austin. Reference videos are credited on each sign's drill page.
            </p>
          </div>
          <Button variant="link" onClick={() => navigate("/about")}>Read the credits →</Button>
        </div>
      </section>
    </MarketingShell>
  );
}

function SignInScreen() {
  const [email, setEmail] = React.useState("");
  const [pw, setPw] = React.useState("");
  const [err, setErr] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const submit = (e) => {
    e.preventDefault();
    setErr("");
    if (!email.includes("@")) return setErr("Enter a valid email.");
    if (pw.length < 6) return setErr("Password must be at least 6 characters.");
    setBusy(true);
    setTimeout(() => { setBusy(false); navigate("/dashboard"); }, 600);
  };
  return (
    <AuthShell>
      <div className="auth-prose">
        <EyebrowLine>Returning learner</EyebrowLine>
        <h1 className="h-1" style={{ marginTop: 16 }}>Welcome back.</h1>
        <p className="lede" style={{ marginTop: 16 }}>
          Pick up where you left off. Your progress is keyed to this device — sign in to sync across browsers.
        </p>
        <p className="footnote" style={{ marginTop: 24 }}>
          New to the pilot? <a href="#/signup" onClick={(e) => { e.preventDefault(); navigate("/signup"); }} style={{ color: "var(--accent)", textDecoration: "underline" }}>Create an account</a> instead.
        </p>
      </div>
      <form className="auth-form card" onSubmit={submit} noValidate>
        <Eyebrow>Sign in</Eyebrow>
        <div className="stack" style={{ gap: 18, marginTop: 16 }}>
          <Field label="Email" htmlFor="email">
            <Input id="email" type="email" autoComplete="email" placeholder="you@school.edu" value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label="Password" htmlFor="pw" action={<a href="#/forgot" onClick={(e) => { e.preventDefault(); navigate("/forgot"); }} style={{ fontSize: "0.8rem", color: "var(--accent)" }}>Forgot?</a>}>
            <Input id="pw" type="password" autoComplete="current-password" value={pw} onChange={(e) => setPw(e.target.value)} />
          </Field>
          {err && <div className="error-text">{err}</div>}
          <Button variant="primary" size="lg" type="submit" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</Button>
          <Rule />
          <div className="row" style={{ justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
            <span className="help">Or try the demo without signing up.</span>
            <Button variant="secondary" size="sm" onClick={() => navigate("/onboarding")}>Demo as guest</Button>
          </div>
        </div>
      </form>
    </AuthShell>
  );
}

function SignUpScreen() {
  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [pw, setPw] = React.useState("");
  const [pw2, setPw2] = React.useState("");
  const [err, setErr] = React.useState({});
  const submit = (e) => {
    e.preventDefault();
    const next = {};
    if (!name.trim()) next.name = "We'll use this to greet you.";
    if (!email.includes("@")) next.email = "That doesn't look like an email.";
    if (pw.length < 8) next.pw = "Eight characters minimum.";
    if (pw !== pw2) next.pw2 = "Passwords don't match.";
    setErr(next);
    if (Object.keys(next).length === 0) navigate("/verify");
  };
  return (
    <AuthShell>
      <div className="auth-prose">
        <EyebrowLine>New learner</EyebrowLine>
        <h1 className="h-1" style={{ marginTop: 16 }}>Begin the pilot.</h1>
        <p className="lede" style={{ marginTop: 16 }}>
          Free for the pilot cohort. We'll send a verification email, then a short calibration — about three minutes from here to your first sign.
        </p>
        <div className="auth-checklist">
          <div className="auth-check"><span className="auth-check-num mono">01</span> One-tap email verification</div>
          <div className="auth-check"><span className="auth-check-num mono">02</span> Camera permission & framing</div>
          <div className="auth-check"><span className="auth-check-num mono">03</span> First sign: <em>HELLO</em></div>
        </div>
      </div>
      <form className="auth-form card" onSubmit={submit} noValidate>
        <Eyebrow>Create your account</Eyebrow>
        <div className="stack" style={{ gap: 16, marginTop: 16 }}>
          <Field label="Display name" htmlFor="name" error={err.name}>
            <Input id="name" placeholder="Alex" value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="Email" htmlFor="email2" hint="We never share this. Used only for verification and password reset." error={err.email}>
            <Input id="email2" type="email" placeholder="you@school.edu" value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <div className="auth-pw-row">
            <Field label="Password" htmlFor="pw3" error={err.pw}>
              <Input id="pw3" type="password" value={pw} onChange={(e) => setPw(e.target.value)} />
            </Field>
            <Field label="Confirm" htmlFor="pw4" error={err.pw2}>
              <Input id="pw4" type="password" value={pw2} onChange={(e) => setPw2(e.target.value)} />
            </Field>
          </div>
          <Button variant="primary" size="lg" type="submit">Create account</Button>
          <p className="footnote">
            Already have one? <a href="#/signin" onClick={(e) => { e.preventDefault(); navigate("/signin"); }} style={{ color: "var(--accent)", textDecoration: "underline" }}>Sign in</a>.
          </p>
        </div>
      </form>
    </AuthShell>
  );
}

function ForgotScreen() {
  const [email, setEmail] = React.useState("");
  const [sent, setSent] = React.useState(false);
  return (
    <AuthShell>
      <div className="auth-prose">
        <EyebrowLine>Reset</EyebrowLine>
        <h1 className="h-1" style={{ marginTop: 16 }}>Forgot your password.</h1>
        <p className="lede" style={{ marginTop: 16 }}>
          Enter the email you signed up with. We'll send a one-time link to set a new one. Links expire in fifteen minutes.
        </p>
      </div>
      {!sent ? (
        <form className="auth-form card" onSubmit={(e) => { e.preventDefault(); setSent(true); }}>
          <Eyebrow>Reset password</Eyebrow>
          <div className="stack" style={{ gap: 16, marginTop: 16 }}>
            <Field label="Email" htmlFor="emailf">
              <Input id="emailf" type="email" placeholder="you@school.edu" value={email} onChange={(e) => setEmail(e.target.value)} />
            </Field>
            <Button variant="primary" size="lg" type="submit">Send reset link</Button>
            <p className="footnote">
              Remembered it? <a href="#/signin" onClick={(e) => { e.preventDefault(); navigate("/signin"); }} style={{ color: "var(--accent)", textDecoration: "underline" }}>Back to sign in</a>.
            </p>
          </div>
        </form>
      ) : (
        <div className="auth-form card">
          <Badge variant="success">Sent</Badge>
          <h2 className="h-3" style={{ marginTop: 12 }}>Check your inbox.</h2>
          <p className="body-prose" style={{ marginTop: 8, fontSize: "0.95rem" }}>
            If <span className="mono" style={{ color: "var(--fg)" }}>{email}</span> is on file, a reset link is on the way. It can take a minute. Check spam if it doesn't arrive.
          </p>
          <div className="row" style={{ gap: 12, marginTop: 20, flexWrap: "wrap" }}>
            <Button variant="secondary" onClick={() => setSent(false)}>Try a different address</Button>
            <Button variant="ghost" onClick={() => navigate("/signin")}>Back to sign in</Button>
          </div>
        </div>
      )}
    </AuthShell>
  );
}

function VerifyEmailScreen() {
  const [resent, setResent] = React.useState(false);
  return (
    <AuthShell>
      <div className="auth-prose">
        <EyebrowLine>One more step</EyebrowLine>
        <h1 className="h-1" style={{ marginTop: 16 }}>Verify your email.</h1>
        <p className="lede" style={{ marginTop: 16 }}>
          We sent a six-digit code to <span className="mono" style={{ color: "var(--fg)" }}>alex@school.edu</span>. Enter it here, or click the link in the message — either works.
        </p>
        <p className="footnote" style={{ marginTop: 24 }}>
          Wrong address? <a href="#/signup" onClick={(e) => { e.preventDefault(); navigate("/signup"); }} style={{ color: "var(--accent)", textDecoration: "underline" }}>Back to sign-up</a> to change it.
        </p>
      </div>
      <div className="auth-form card">
        <Eyebrow>Enter verification code</Eyebrow>
        <CodeInput onComplete={() => navigate("/onboarding")} />
        <div className="row" style={{ justifyContent: "space-between", alignItems: "center", marginTop: 24, flexWrap: "wrap", gap: 12 }}>
          <span className="help">Didn't get the code?</span>
          <Button variant="link" onClick={() => setResent(true)}>{resent ? "Resent ✓" : "Resend"}</Button>
        </div>
      </div>
    </AuthShell>
  );
}

function CodeInput({ onComplete }) {
  const [digits, setDigits] = React.useState(["", "", "", "", "", ""]);
  const refs = React.useRef([]);
  const update = (i, v) => {
    const n = v.replace(/[^0-9]/g, "").slice(-1);
    const next = [...digits];
    next[i] = n;
    setDigits(next);
    if (n && i < 5) refs.current[i + 1]?.focus();
    if (next.every(d => d) && onComplete) setTimeout(() => onComplete(), 300);
  };
  const onKey = (i, e) => {
    if (e.key === "Backspace" && !digits[i] && i > 0) refs.current[i - 1]?.focus();
  };
  return (
    <div className="code-input">
      {digits.map((d, i) => (
        <input key={i} ref={(el) => (refs.current[i] = el)}
          className="code-cell" inputMode="numeric" maxLength={1}
          value={d} onChange={(e) => update(i, e.target.value)} onKeyDown={(e) => onKey(i, e)} />
      ))}
    </div>
  );
}

const SCREENS_PUBLIC_CSS = `
.landing-hero{padding:48px 0 32px}
@media (min-width:768px){.landing-hero{padding:80px 0 48px}}
/* Foundry: dark landing, tight composition, no decorative gradients */
:root[data-direction="foundry"] .landing-hero{
  background:var(--bg);
  margin-bottom:0;
  padding:80px 0 64px;
  position:relative;
  overflow:hidden;
}
:root[data-direction="foundry"] .landing-hero::before{
  content:"";position:absolute;inset:0;pointer-events:none;
  background:
    var(--grad-glow-a, radial-gradient(circle at 80% 20%, rgba(77,159,255,0.10) 0%, transparent 50%));
  background-position:80% 20%;background-size:80% 80%;background-repeat:no-repeat;
}
:root[data-direction="foundry"] .landing-hero::after{
  content:"";position:absolute;inset:0;pointer-events:none;
  background:var(--grad-glow-b, radial-gradient(circle at 10% 90%, rgba(77,159,255,0.06) 0%, transparent 40%));
  background-position:10% 90%;background-size:70% 70%;background-repeat:no-repeat;
}
:root[data-direction="foundry"] .landing-hero > *{position:relative;z-index:1}
:root[data-direction="foundry"] .landing-grid{grid-template-columns:1fr;gap:0;max-width:880px}
:root[data-direction="foundry"] .landing-aside{display:none}
:root[data-direction="foundry"] .landing-title{max-width:22ch;color:var(--fg)}
:root[data-direction="foundry"] .landing-em{font-style:normal;color:var(--accent);text-decoration:none}
:root[data-direction="foundry"] .landing-three{display:none}
:root[data-direction="foundry"] .landing-credit{display:none}
:root[data-direction="foundry"] .landing-hero ~ section{display:none}
:root[data-direction="foundry"] .landing-cta{margin-top:16px}
.landing-grid{display:grid;grid-template-columns:1.4fr 1fr;gap:64px;align-items:start}
@media (max-width:880px){.landing-grid{grid-template-columns:1fr;gap:40px}}
.landing-lede{display:flex;flex-direction:column;gap:24px}
.landing-title{max-width:18ch}
.landing-em{font-style:italic}
:root[data-direction="field"] .landing-em{font-style:normal;border-bottom:2px solid var(--accent);padding-bottom:2px}
:root[data-direction="studio"] .landing-em{font-style:italic;color:var(--accent)}
.landing-cta{display:flex;gap:12px;flex-wrap:wrap;margin-top:8px}
.footnote{font-family:var(--font-ui);font-size:0.85rem;color:var(--fg-subtle);max-width:52ch;line-height:1.5}
.landing-aside{display:flex;flex-direction:column;gap:20px}
.landing-card{margin:0;padding:0;display:flex;flex-direction:column}
.landing-card .media-ph{margin:0}
.landing-cap{padding:16px 4px 4px;display:flex;flex-direction:column;gap:6px}
:root[data-direction="reader"] .landing-cap{border-top:1px solid var(--line);padding-top:14px;margin-top:12px}
.caption-body{font-family:var(--font-body);font-size:0.92rem;line-height:1.5;color:var(--fg-muted);margin:4px 0 0;max-width:32ch}
.landing-meta{list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:6px;font-family:var(--font-ui);font-size:0.88rem;color:var(--fg-muted)}
.landing-meta li{display:flex;gap:10px;align-items:baseline;padding:8px 0;border-bottom:1px solid var(--line-soft)}
.landing-meta .mono{color:var(--fg);font-size:0.95rem;min-width:32px}
.landing-three{display:grid;grid-template-columns:repeat(3,1fr);gap:48px}
@media (max-width:760px){.landing-three{grid-template-columns:1fr;gap:32px}}
.landing-three h3{margin-top:4px}
.landing-three p{font-size:0.96rem}
.landing-credit{padding:48px 0 24px}
.landing-credit-row{display:flex;align-items:flex-end;justify-content:space-between;flex-wrap:wrap;gap:24px;padding-top:24px}
.auth-prose{display:flex;flex-direction:column}
.auth-form{display:flex;flex-direction:column}
.auth-pw-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
@media (max-width:520px){.auth-pw-row{grid-template-columns:1fr}}
.auth-checklist{margin-top:32px;display:flex;flex-direction:column;gap:12px;font-family:var(--font-ui);font-size:0.92rem;color:var(--fg-muted)}
.auth-check{display:flex;gap:14px;align-items:baseline;padding:10px 0;border-top:1px solid var(--line-soft)}
.auth-check:last-child{border-bottom:1px solid var(--line-soft)}
.auth-check-num{color:var(--accent);font-size:0.82rem;min-width:24px}
.auth-check em{font-style:italic;color:var(--fg)}
.code-input{display:flex;gap:8px;margin-top:20px;justify-content:space-between}
.code-cell{width:48px;height:60px;text-align:center;font-family:var(--font-mono);font-size:1.4rem;background:var(--bg-elev);border:1px solid var(--line);border-radius:var(--radius-md);color:var(--fg);outline:none}
.code-cell:focus{border-color:var(--accent);background:var(--bg-paper)}
:root[data-direction="field"] .code-cell{border-radius:0}
@media (max-width:520px){.code-cell{width:40px;height:52px;font-size:1.2rem}}
`;

function injectScreensPublicCSS() {
  if (document.getElementById("__screens_public_css")) return;
  const s = document.createElement("style");
  s.id = "__screens_public_css";
  s.textContent = SCREENS_PUBLIC_CSS;
  document.head.appendChild(s);
}

Object.assign(window, {
  LandingScreen, SignInScreen, SignUpScreen, ForgotScreen, VerifyEmailScreen,
  injectScreensPublicCSS,
});
