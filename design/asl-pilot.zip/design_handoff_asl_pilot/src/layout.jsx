// layout.jsx — Nav, Footer, AuthShell, AppShell, MarketingShell

function navigate(hash) {
  window.location.hash = hash.startsWith("#") ? hash : `#${hash}`;
}

function useHashRoute() {
  const [hash, setHash] = React.useState(() => window.location.hash || "#/");
  React.useEffect(() => {
    const onHash = () => setHash(window.location.hash || "#/");
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);
  return [hash.replace(/^#/, ""), navigate];
}

function NavLink({ to, children, active }) {
  return (
    <a href={`#${to}`} className={active ? "active" : ""}
       onClick={(e) => { e.preventDefault(); navigate(to); }}>
      {children}
    </a>
  );
}

function AuthedNav({ path }) {
  const links = [
    { to: "/lessons", label: "Lessons" },
    { to: "/dashboard", label: "Dashboard" },
    { to: "/settings", label: "Settings" },
    { to: "/help", label: "Help" },
  ];
  return (
    <nav className="nav">
      <a href="#/dashboard" onClick={(e) => { e.preventDefault(); navigate("/dashboard"); }}>
        <Brand />
      </a>
      <div className="nav-links">
        {links.map(l => <NavLink key={l.to} to={l.to} active={path.startsWith(l.to)}>{l.label}</NavLink>)}
      </div>
      <div className="nav-meta">
        <span className="mono" style={{ fontSize: "0.78rem", color: "var(--fg-subtle)" }}>Alex Rivera</span>
        <button className="btn btn-ghost btn-sm" onClick={() => navigate("/")}>Sign out</button>
      </div>
    </nav>
  );
}

function PublicNav() {
  return (
    <nav className="nav">
      <a href="#/" onClick={(e) => { e.preventDefault(); navigate("/"); }}><Brand /></a>
      <div className="nav-links">
        <NavLink to="/about">About</NavLink>
        <NavLink to="/help">Help</NavLink>
        <NavLink to="/privacy">Privacy</NavLink>
      </div>
      <div className="nav-meta">
        <Button variant="ghost" size="sm" onClick={() => navigate("/signin")}>Sign in</Button>
        <Button variant="primary" size="sm" onClick={() => navigate("/signup")}>Create account</Button>
      </div>
    </nav>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <span className="footer-mark">A Superbuilders project · Made in Austin, TX</span>
      <div className="footer-links">
        <a href="#/privacy" onClick={(e) => { e.preventDefault(); navigate("/privacy"); }}>Privacy</a>
        <a href="#/about" onClick={(e) => { e.preventDefault(); navigate("/about"); }}>About & credits</a>
        <a href="#/help" onClick={(e) => { e.preventDefault(); navigate("/help"); }}>Help</a>
        <span>v0.2 — pilot</span>
      </div>
    </footer>
  );
}

// Pages used inside auth (sign in, sign up etc) — centered, no app nav
function AuthShell({ children }) {
  return (
    <div className="auth-shell">
      <header className="auth-header">
        <a href="#/" onClick={(e) => { e.preventDefault(); navigate("/"); }}><Brand /></a>
      </header>
      <main className="auth-main">
        <div className="auth-grid">{children}</div>
      </main>
      <Footer />
    </div>
  );
}

function AppShell({ path, children }) {
  return (
    <div className="app-shell">
      <AuthedNav path={path} />
      <main className="app-main">{children}</main>
      <Footer />
    </div>
  );
}

function MarketingShell({ children }) {
  return (
    <div className="marketing-shell">
      <PublicNav />
      <main>{children}</main>
      <Footer />
    </div>
  );
}

const LAYOUT_CSS = `
.auth-shell, .app-shell, .marketing-shell{min-height:100vh;display:flex;flex-direction:column}
.auth-header{padding:24px 32px;border-bottom:1px solid var(--line-soft)}
:root[data-direction="reader"] .auth-header{border-bottom-style:double;border-bottom-width:3px}
.auth-main{flex:1;display:flex;align-items:center;justify-content:center;padding:48px 24px}
.auth-grid{
  width:100%;max-width:1000px;display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center;
}
@media (max-width:880px){.auth-grid{grid-template-columns:1fr;gap:32px}}
.app-main{flex:1;padding:32px 0 64px}
@media (max-width:760px){.app-main{padding:20px 0 48px}}
`;

function injectLayoutCSS() {
  if (document.getElementById("__layout_css")) return;
  const s = document.createElement("style");
  s.id = "__layout_css";
  s.textContent = LAYOUT_CSS;
  document.head.appendChild(s);
}

Object.assign(window, {
  navigate, useHashRoute, NavLink,
  AuthedNav, PublicNav, Footer,
  AuthShell, AppShell, MarketingShell,
  injectLayoutCSS,
});
